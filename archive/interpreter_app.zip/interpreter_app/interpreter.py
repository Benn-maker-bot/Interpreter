import customtkinter as ctk
import speech_recognition as sr
import threading
import queue

from deep_translator import GoogleTranslator

try:
    import pyaudio
    _PYAUDIO_AVAILABLE = True
except Exception:
    _PYAUDIO_AVAILABLE = False

try:
    import pyttsx3
    _TTS_AVAILABLE = True
except Exception:
    _TTS_AVAILABLE = False

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

LANGUAGES = {
    "Arabic":                ("ar-SA",  "ar"),
    "Chinese (Mandarin)":    ("zh-CN",  "zh-CN"),
    "Chinese (Cantonese)":   ("zh-TW",  "zh-TW"),
    "Dutch":                 ("nl-NL",  "nl"),
    "French":                ("fr-FR",  "fr"),
    "German":                ("de-DE",  "de"),
    "Greek":                 ("el-GR",  "el"),
    "Gujarati":              ("gu-IN",  "gu"),
    "Hindi":                 ("hi-IN",  "hi"),
    "Indonesian":            ("id-ID",  "id"),
    "Italian":               ("it-IT",  "it"),
    "Japanese":              ("ja-JP",  "ja"),
    "Korean":                ("ko-KR",  "ko"),
    "Malay":                 ("ms-MY",  "ms"),
    "Marathi":               ("mr-IN",  "mr"),
    "Polish":                ("pl-PL",  "pl"),
    "Portuguese (Brazil)":   ("pt-BR",  "pt"),
    "Portuguese (Portugal)": ("pt-PT",  "pt"),
    "Punjabi":               ("pa-IN",  "pa"),
    "Romanian":              ("ro-RO",  "ro"),
    "Russian":               ("ru-RU",  "ru"),
    "Spanish":               ("es-ES",  "es"),
    "Swahili":               ("sw-KE",  "sw"),
    "Tamil":                 ("ta-IN",  "ta"),
    "Telugu":                ("te-IN",  "te"),
    "Thai":                  ("th-TH",  "th"),
    "Turkish":               ("tr-TR",  "tr"),
    "Ukrainian":             ("uk-UA",  "uk"),
    "Urdu":                  ("ur-PK",  "ur"),
    "Vietnamese":            ("vi-VN",  "vi"),
}

# Keywords that identify VB-Audio virtual cable devices
VB_AUDIO_KEYWORDS = ["cable output", "vb-audio", "vb audio", "voicemeeter", "virtual cable"]


def get_audio_input_devices():
    """
    Return a list of (index, label) tuples for every available audio input device.
    Devices matching VB-Audio keywords are flagged with a ★ prefix.
    Falls back to [(-1, "Default Microphone")] if PyAudio is unavailable.
    """
    devices = []
    if not _PYAUDIO_AVAILABLE:
        return [(-1, "Default Microphone")]

    try:
        pa = pyaudio.PyAudio()
        seen = set()
        for i in range(pa.get_device_count()):
            info = pa.get_device_info_by_index(i)
            if info.get("maxInputChannels", 0) < 1:
                continue
            name = info["name"]
            if name in seen:
                continue
            seen.add(name)

            name_lower = name.lower()
            is_vb = any(kw in name_lower for kw in VB_AUDIO_KEYWORDS)
            label = f"★ {name}" if is_vb else name
            devices.append((i, label))
        pa.terminate()
    except Exception:
        pass

    if not devices:
        devices = [(-1, "Default Microphone")]

    return devices


class InterpreterApp(ctk.CTk):

    def __init__(self):
        super().__init__()
        self.title("Voice Interpreter")
        self.geometry("860x640")
        self.minsize(700, 520)

        self.result_queue = queue.Queue()
        self.recognizer = sr.Recognizer()
        self.is_listening = False
        self.stop_fn = None

        self.tts = None
        if _TTS_AVAILABLE:
            try:
                self.tts = pyttsx3.init()
            except Exception:
                pass

        # ── Audio devices ──────────────────────────────────────────────────
        self.audio_devices = get_audio_input_devices()
        # Map label → index for lookup
        self._device_map = {label: idx for idx, label in self.audio_devices}
        device_labels = [label for _, label in self.audio_devices]

        # Auto-select VB-Audio cable if present
        default_device = device_labels[0]
        for label in device_labels:
            if label.startswith("★"):
                default_device = label
                break

        self.device_var = ctk.StringVar(value=default_device)

        # ── Layout ─────────────────────────────────────────────────────────
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        self._build_header()
        self._build_controls(device_labels)
        self._build_text_area()
        self._build_status_bar()

        self.after(100, self._poll_queue)

    # ─────────────────────────────────────────── UI builders ──────────────

    def _build_header(self):
        hdr = ctk.CTkFrame(self, corner_radius=0, fg_color=("gray85", "gray17"))
        hdr.grid(row=0, column=0, sticky="ew", padx=0, pady=0)
        hdr.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            hdr,
            text="🎙  Voice Interpreter",
            font=ctk.CTkFont(size=22, weight="bold"),
        ).grid(row=0, column=0, pady=(14, 2))

        ctk.CTkLabel(
            hdr,
            text="Capture audio from any source · Transcribe · Translate to English",
            font=ctk.CTkFont(size=12),
            text_color=("gray50", "gray60"),
        ).grid(row=1, column=0, pady=(0, 12))

    def _build_controls(self, device_labels):
        bar = ctk.CTkFrame(self, fg_color="transparent")
        bar.grid(row=1, column=0, sticky="ew", padx=20, pady=(14, 0))
        bar.grid_columnconfigure(1, weight=1)

        # ── Row 0: Audio source ────────────────────────────────────────────
        ctk.CTkLabel(bar, text="Audio source:", font=ctk.CTkFont(size=13)).grid(
            row=0, column=0, sticky="w", padx=(0, 8)
        )
        self.device_menu = ctk.CTkOptionMenu(
            bar,
            variable=self.device_var,
            values=device_labels,
            width=380,
            command=self._on_device_change,
        )
        self.device_menu.grid(row=0, column=1, sticky="w")

        refresh_btn = ctk.CTkButton(
            bar,
            text="⟳",
            width=36,
            command=self._refresh_devices,
            fg_color=("gray75", "gray30"),
            hover_color=("gray65", "gray40"),
            text_color=("gray10", "gray90"),
        )
        refresh_btn.grid(row=0, column=2, padx=(8, 0))

        # ── Row 1: Language + action buttons ──────────────────────────────
        lang_bar = ctk.CTkFrame(self, fg_color="transparent")
        lang_bar.grid(row=2, column=0, sticky="ew", padx=20, pady=(10, 0))
        lang_bar.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(lang_bar, text="Speaker language:", font=ctk.CTkFont(size=13)).grid(
            row=0, column=0, sticky="w", padx=(0, 8)
        )

        self.lang_var = ctk.StringVar(value="French")
        self.lang_menu = ctk.CTkOptionMenu(
            lang_bar,
            variable=self.lang_var,
            values=sorted(LANGUAGES.keys()),
            width=220,
        )
        self.lang_menu.grid(row=0, column=1, sticky="w")

        btn_frame = ctk.CTkFrame(lang_bar, fg_color="transparent")
        btn_frame.grid(row=0, column=2, sticky="e", padx=(12, 0))

        self.mic_btn = ctk.CTkButton(
            btn_frame,
            text="▶   Start Listening",
            width=160,
            command=self._toggle_listening,
        )
        self.mic_btn.grid(row=0, column=0, padx=(0, 8))

        self.read_btn = ctk.CTkButton(
            btn_frame,
            text="🔊  Read Aloud",
            width=130,
            command=self._speak_translation,
            fg_color=("gray75", "gray30"),
            hover_color=("gray65", "gray40"),
            text_color=("gray10", "gray90"),
        )
        self.read_btn.grid(row=0, column=1, padx=(0, 8))

        ctk.CTkButton(
            btn_frame,
            text="Clear",
            width=70,
            command=self._clear,
            fg_color=("gray75", "gray30"),
            hover_color=("gray65", "gray40"),
            text_color=("gray10", "gray90"),
        ).grid(row=0, column=2)

    def _build_text_area(self):
        frame = ctk.CTkFrame(self, fg_color="transparent")
        frame.grid(row=3, column=0, sticky="nsew", padx=20, pady=(14, 0))
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_columnconfigure(1, weight=1)
        frame.grid_rowconfigure(1, weight=1)
        self.grid_rowconfigure(3, weight=1)

        ctk.CTkLabel(frame, text="Heard (original)", font=ctk.CTkFont(size=12, weight="bold")).grid(
            row=0, column=0, sticky="w", padx=4, pady=(0, 4)
        )
        ctk.CTkLabel(frame, text="English translation", font=ctk.CTkFont(size=12, weight="bold")).grid(
            row=0, column=1, sticky="w", padx=(12, 4), pady=(0, 4)
        )

        self.heard_box = ctk.CTkTextbox(frame, wrap="word", font=ctk.CTkFont(size=14))
        self.heard_box.grid(row=1, column=0, sticky="nsew", padx=(0, 6))

        self.translated_box = ctk.CTkTextbox(frame, wrap="word", font=ctk.CTkFont(size=14))
        self.translated_box.grid(row=1, column=1, sticky="nsew", padx=(6, 0))

    def _build_status_bar(self):
        self.status_var = ctk.StringVar(value='Select your audio source above, then press "Start Listening".')
        bar = ctk.CTkLabel(
            self,
            textvariable=self.status_var,
            font=ctk.CTkFont(size=11),
            text_color=("gray50", "gray55"),
            anchor="w",
        )
        bar.grid(row=4, column=0, sticky="ew", padx=22, pady=(6, 10))

    # ────────────────────────────────────── Device management ─────────────

    def _on_device_change(self, _=None):
        """Stop listening if active when the user switches device."""
        if self.is_listening:
            self._stop_listening()
            self.status_var.set("Audio source changed — press Start Listening again.")

    def _refresh_devices(self):
        """Re-scan audio devices and refresh the dropdown."""
        if self.is_listening:
            self._stop_listening()

        self.audio_devices = get_audio_input_devices()
        self._device_map = {label: idx for idx, label in self.audio_devices}
        device_labels = [label for _, label in self.audio_devices]

        self.device_menu.configure(values=device_labels)

        # Keep current selection if still present, else reset
        current = self.device_var.get()
        if current not in device_labels:
            best = device_labels[0]
            for lbl in device_labels:
                if lbl.startswith("★"):
                    best = lbl
                    break
            self.device_var.set(best)

        self.status_var.set(f"Refreshed — {len(device_labels)} input device(s) found.")

    def _get_selected_device_index(self):
        """Return the PyAudio device index for the currently selected device, or None for default."""
        label = self.device_var.get()
        idx = self._device_map.get(label, -1)
        return None if idx == -1 else idx

    # ────────────────────────────────────── Listening ─────────────────────

    def _toggle_listening(self):
        if self.is_listening:
            self._stop_listening()
        else:
            self._start_listening()

    def _start_listening(self):
        self.is_listening = True
        self.mic_btn.configure(
            text="⏹   Stop Listening",
            fg_color="#C0392B",
            hover_color="#A93226",
        )
        self.lang_menu.configure(state="disabled")
        self.device_menu.configure(state="disabled")

        device_idx = self._get_selected_device_index()
        device_label = self.device_var.get()
        self.status_var.set(f"Listening via: {device_label} …")

        lang_key = self.lang_var.get()
        sr_lang, _ = LANGUAGES.get(lang_key, ("fr-FR", "fr"))

        def callback(recognizer, audio):
            try:
                text = recognizer.recognize_google(audio, language=sr_lang)
                if text.strip():
                    self.result_queue.put(("heard", text))
                    threading.Thread(
                        target=self._do_translate,
                        args=(text, lang_key),
                        daemon=True,
                    ).start()
            except sr.UnknownValueError:
                pass
            except sr.RequestError as e:
                self.result_queue.put(("status", f"Speech API error: {e}"))

        try:
            mic = sr.Microphone(device_index=device_idx)
            # Calibrate for ambient noise on first open
            with mic as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
            self.stop_fn = self.recognizer.listen_in_background(
                mic, callback, phrase_time_limit=12
            )
        except OSError as e:
            self.result_queue.put(("status", f"Audio device error: {e}"))
            self.is_listening = False
            self.mic_btn.configure(
                text="▶   Start Listening",
                fg_color=["#3B8ED0", "#1F6AA5"],
                hover_color=["#3281BC", "#1A5C8F"],
            )
            self.lang_menu.configure(state="normal")
            self.device_menu.configure(state="normal")

    def _stop_listening(self):
        self.is_listening = False
        if self.stop_fn:
            try:
                self.stop_fn(wait_for_stop=False)
            except Exception:
                pass
            self.stop_fn = None
        self.mic_btn.configure(
            text="▶   Start Listening",
            fg_color=["#3B8ED0", "#1F6AA5"],
            hover_color=["#3281BC", "#1A5C8F"],
        )
        self.lang_menu.configure(state="normal")
        self.device_menu.configure(state="normal")
        self.status_var.set('Stopped. Press "Start Listening" to resume.')

    # ────────────────────────────────────── Translation ───────────────────

    def _do_translate(self, text, lang_key):
        _, tr_lang = LANGUAGES.get(lang_key, ("fr-FR", "fr"))
        try:
            if tr_lang.startswith("en"):
                self.result_queue.put(("translated", text))
            else:
                result = GoogleTranslator(source=tr_lang, target="en").translate(text)
                self.result_queue.put(("translated", result or text))
        except Exception as e:
            self.result_queue.put(("status", f"Translation error: {e}"))

    # ────────────────────────────────────── TTS ───────────────────────────

    def _speak_translation(self):
        if not self.tts:
            self.status_var.set("Text-to-speech not available on this system.")
            return
        text = self.translated_box.get("1.0", "end-1c").strip()
        if not text:
            self.status_var.set("Nothing to read — translate something first.")
            return

        def _run():
            try:
                self.tts.say(text)
                self.tts.runAndWait()
            except Exception:
                pass

        threading.Thread(target=_run, daemon=True).start()

    # ────────────────────────────────────── Helpers ───────────────────────

    def _clear(self):
        if self.is_listening:
            self._stop_listening()
        self._set_text(self.heard_box, "")
        self._set_text(self.translated_box, "")
        self.status_var.set('Cleared. Press "Start Listening" to begin.')

    @staticmethod
    def _set_text(box, text):
        box.configure(state="normal")
        box.delete("1.0", "end")
        if text:
            box.insert("end", text)

    @staticmethod
    def _append_text(box, text):
        box.configure(state="normal")
        current = box.get("1.0", "end-1c")
        if current:
            box.insert("end", "\n" + text)
        else:
            box.insert("end", text)
        box.see("end")

    # ────────────────────────────────────── Queue poll ────────────────────

    def _poll_queue(self):
        try:
            while True:
                kind, data = self.result_queue.get_nowait()
                if kind == "heard":
                    self._append_text(self.heard_box, data)
                    self.status_var.set("Recognised — translating…")
                elif kind == "translated":
                    self._append_text(self.translated_box, data)
                    msg = ("Translated. Still listening…" if self.is_listening
                           else "Translation complete.")
                    self.status_var.set(msg)
                elif kind == "status":
                    self.status_var.set(data)
        except queue.Empty:
            pass
        self.after(100, self._poll_queue)


if __name__ == "__main__":
    app = InterpreterApp()
    app.mainloop()
