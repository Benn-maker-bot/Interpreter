@echo off
title Voice Interpreter - Build EXE
color 0B
echo.
echo  ==========================================
echo   Voice Interpreter - Build Standalone EXE
echo  ==========================================
echo.
echo  This will create a single .exe you can share
echo  and run without Python installed.
echo.
echo  Estimated time: 1-3 minutes.
echo.
pause

echo.
echo  [1/3] Installing dependencies...
pip install customtkinter SpeechRecognition deep-translator pyttsx3 pyaudio pyinstaller --quiet

echo.
echo  [2/3] Building executable...
pyinstaller ^
  --onefile ^
  --windowed ^
  --name "VoiceInterpreter" ^
  --collect-all customtkinter ^
  --hidden-import pyttsx3.drivers ^
  --hidden-import pyttsx3.drivers.sapi5 ^
  --hidden-import speech_recognition ^
  --hidden-import pyaudio ^
  interpreter.py

echo.
echo  [3/3] Done!
echo.
if exist "dist\VoiceInterpreter.exe" (
    echo  SUCCESS: Your app is at:
    echo.
    echo    dist\VoiceInterpreter.exe
    echo.
    echo  You can move that file anywhere and run it directly.
    explorer dist
) else (
    echo  Build may have had issues - check the output above.
)

pause
