Voice Interpreter
=================
Real-time speech recognition and translation to English.
Supports physical microphones AND virtual audio cables (VB-Audio, Voicemeeter, etc.)


VIRTUAL AUDIO CABLE SETUP (for Teams, Zoom, etc.)
--------------------------------------------------
To capture audio from apps like Microsoft Teams:

  1. In the app you want to capture (e.g. Teams):
     Settings → Devices → Speaker → set to "CABLE Input (VB-Audio Virtual Cable)"

  2. Open Voice Interpreter
     The "CABLE Output" device will appear with a ★ star and be auto-selected.

  3. Press "Start Listening" — the app now hears everything Teams plays.

  NOTE: When routing Teams audio to the cable, you won't hear it through
  your normal speakers. Use headphones and set your headphone output
  separately in Teams, OR use Voicemeeter to split the audio.


QUICK START
-----------
Option A — Run directly with Python:
  1. Install Python 3.9+ from https://python.org
     (tick "Add Python to PATH" during install)
  2. Double-click setup_and_run.bat

Option B — Build a standalone .exe:
  1. Follow Option A once first
  2. Double-click build_exe.bat
  3. Your .exe will appear in the dist\ folder


HOW TO USE
----------
  1. Select your audio source from the "Audio source" dropdown
     (★ devices are VB-Audio virtual cables, auto-selected if present)
  2. Select the language being spoken
  3. Click "Start Listening"
  4. Speech appears on the left; English translation on the right
  5. Click "Read Aloud" to have the translation spoken through your speakers
  6. Use ⟳ to refresh the device list if you plug in new hardware


TROUBLESHOOTING
---------------
  VB-Audio cable not appearing in dropdown:
    → Make sure VB-Audio Virtual Cable is installed from vb-audio.com
    → Click the ⟳ refresh button
    → Check it appears as a recording device in Windows Sound settings

  "Audio device error":
    → Another app may be exclusively using that device
    → Try setting the device to "Shared" mode in Windows Sound settings

  "Speech API error":
    → Check your internet connection (Google Speech API is required)

  PyAudio install fails:
    → Run in Command Prompt:
        pip install pipwin
        pipwin install pyaudio


PRIVACY
-------
  Audio is sent to Google's Speech Recognition API for transcription,
  and to Google Translate for translation. No data is stored by this app.
