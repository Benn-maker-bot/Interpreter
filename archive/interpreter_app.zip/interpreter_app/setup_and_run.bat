@echo off
title Voice Interpreter - Setup
color 0A
echo.
echo  ==========================================
echo   Voice Interpreter - First-time Setup
echo  ==========================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found.
    echo.
    echo  Please install Python 3.9+ from https://python.org
    echo  Make sure to tick "Add Python to PATH" during install.
    echo.
    pause
    exit /b 1
)

echo  [OK] Python found.
echo.
echo  Installing required packages - this may take a minute...
echo.

pip install customtkinter SpeechRecognition deep-translator pyttsx3 pyaudio --quiet
if errorlevel 1 (
    echo.
    echo  PyAudio install failed. Trying alternative method...
    pip install pipwin --quiet
    pipwin install pyaudio --quiet
)

echo.
echo  [OK] Setup complete. Starting Voice Interpreter...
echo.
python interpreter.py
pause
