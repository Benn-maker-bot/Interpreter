"""
Voice Interpreter — fixed, optimised, with structured JSONL debug logging.

Bug fixes vs previous version:
  • Model inference lock: WhisperModel.transcribe() is not thread-safe when
    called concurrently from multiple workers on the same instance.
    A threading.Lock() now serialises inference calls so workers safely
    queue up rather than corrupting each other's state.
  • Translation fallback: uses requests directly if available, falls back
    to deep_translator, with clear error logging if both fail.
  • All exceptions in background threads are caught and logged/surfaced.

Logging:
  • Writes interpreter_debug.jsonl next to interpreter.py (JSON Lines).
  • Every event is one self-contained JSON object per line — easy to grep,
    parse with jq, or load into Python with [json.loads(l) for l in file].
  • Fields: timestamp, level, component, event, data{}
  • Levels: DEBUG / INFO / WARNING / ERROR
"""

import json
import logging
import os
import queue
import struct
import sys
import math
import threading
import time
import traceback
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path

import customtkinter as ctk

try:
    import pyaudio
    _PYAUDIO_AVAILABLE = True
except ImportError:
    _PYAUDIO_AVAILABLE = False

try:
    import pyttsx3
    _TTS_AVAILABLE = True
except Exception:
    _TTS_AVAILABLE = False

try:
    import requests as _requests_lib
    _REQUESTS_AVAILABLE = True
except ImportError:
    _REQUESTS_AVAILABLE = False

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# ── Paths ──────────────────────────────────────────────────────────────────────
_APP_DIR  = Path(__file__).parent.resolve()
_LOG_PATH = _APP_DIR / "interpreter_debug.jsonl"

# ── Audio / VAD ────────────────────────────────────────────────────────────────
SAMPLE_RATE      = 16_000
CHUNK_SAMPLES    = 512
CHANNELS         = 1
SAMPLE_WIDTH     = 2
SILENCE_SEC      = 0.25
STREAM_CHUNK_SEC = 1.2
MAX_PHRASE_SEC   = 6
MIN_PHRASE_SEC   = 0.10
CAL_MULTIPLIER   = 1.3
DEFAULT_SENS     = 0.6

VB_KEYWORDS     = ["cable output", "vb-audio", "vb audio", "voicemeeter", "virtual cable"]
NVIDIA_KEYWORDS = ["nvidia", "broadcast", "rtx voice"]

MODELS = {
    "Tiny  — fastest":          "tiny",
    "Small — recommended ✓":   "small",
    "Medium — most accurate":   "medium",
}
DEFAULT_MODEL_CPU = "Tiny  — fastest"
DEFAULT_MODEL_GPU = "Small — recommended ✓"

LANGUAGES = {
    "English":            ("en", "en"),
    "Russian":            ("ru", "ru"),
    "Arabic":             ("ar", "ar"),
    "Chinese (Mandarin)": ("zh", "zh-CN"),
    "Dutch":              ("nl", "nl"),
    "French":             ("fr", "fr"),
    "German":             ("de", "de"),
    "Greek":              ("el", "el"),
    "Hindi":              ("hi", "hi"),
    "Italian":            ("it", "it"),
    "Japanese":           ("ja", "ja"),
    "Korean":             ("ko", "ko"),
    "Polish":             ("pl", "pl"),
    "Portuguese":         ("pt", "pt"),
    "Spanish":            ("es", "es"),
    "Turkish":            ("tr", "tr"),
    "Ukrainian":          ("uk", "uk"),
}

COL_MY_VOICE = ("#1A6B3A", "#1A6B3A")
COL_MY_HOVER = ("#155730", "#155730")
COL_FRIEND   = ("#1A4A7A", "#1A4A7A")
COL_FR_HOVER = ("#153D66", "#153D66")
COL_INACTIVE = ("gray30",  "gray25")
COL_IN_HOVER = ("gray40",  "gray35")
COL_STOP     = "#C0392B"
COL_STOP_HOV = "#A93226"


# ─────────────────────────────────────────────────────────────────────────────
# Structured JSONL logger
# ─────────────────────────────────────────────────────────────────────────────

class AppLogger:
    """
    Writes one JSON object per line to interpreter_debug.jsonl.
    Thread-safe. Each entry:
      {
        "ts":        "2025-05-10T14:23:01.123Z",   # ISO-8601 UTC
        "level":     "INFO",                         # DEBUG/INFO/WARNING/ERROR
        "component": "transcription",                # subsystem
        "event":     "phrase_received",              # what happened
        "data":      { ... }                         # context dict
      }
    """

    LEVELS = {"DEBUG": 10, "INFO": 20, "WARNING": 30, "ERROR": 40}

    def __init__(self, path: Path, min_level: str = "DEBUG"):
        self._path      = path
        self._min       = self.LEVELS.get(min_level, 10)
        self._lock      = threading.Lock()
        self._file      = None
        self._open()

    def _open(self):
        try:
            self._file = open(self._path, "a", encoding="utf-8", buffering=1)
            self._write("INFO", "logger", "session_start", {
                "log_file": str(self._path),
                "python":   sys.version,
                "platform": sys.platform,
            })
        except Exception as e:
            print(f"[Logger] Cannot open log file: {e}", file=sys.stderr)

    def _write(self, level: str, component: str, event: str, data: dict):
        if self.LEVELS.get(level, 0) < self._min:
            return
        entry = {
            "ts":        datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
            "level":     level,
            "component": component,
            "event":     event,
            "data":      data,
        }
        line = json.dumps(entry, ensure_ascii=False)
        with self._lock:
            if self._file:
                try:
                    self._file.write(line + "\n")
                except Exception:
                    pass

    # Convenience methods
    def debug(self, component, event, **data):
        self._write("DEBUG", component, event, data)

    def info(self, component, event, **data):
        self._write("INFO", component, event, data)

    def warning(self, component, event, **data):
        self._write("WARNING", component, event, data)

    def error(self, component, event, exc: Exception = None, **data):
        if exc is not None:
            data["exception"]  = type(exc).__name__
            data["message"]    = str(exc)
            data["traceback"]  = traceback.format_exc()
        self._write("ERROR", component, event, data)

    def close(self):
        self._write("INFO", "logger", "session_end", {})
        with self._lock:
            if self._file:
                self._file.close()
                self._file = None


# Module-level logger (initialised before anything else)
log = AppLogger(_LOG_PATH)


# ─────────────────────────────────────────────────────────────────────────────
# GPU detection
# ─────────────────────────────────────────────────────────────────────────────

def detect_device():
    try:
        import ctranslate2
        n = ctranslate2.get_cuda_device_count()
        log.info("startup", "gpu_check", cuda_devices=n)
        if n > 0:
            log.info("startup", "using_gpu", device="cuda", compute="float16")
            return "cuda", "float16", 2, DEFAULT_MODEL_GPU
    except Exception as e:
        log.warning("startup", "gpu_check_failed", message=str(e))
    log.info("startup", "using_cpu", compute="int8")
    return "cpu", "int8", 3, DEFAULT_MODEL_CPU

WHISPER_DEVICE, COMPUTE_TYPE, NUM_WORKERS, _DEFAULT_MODEL = detect_device()


# ─────────────────────────────────────────────────────────────────────────────
# Translation — persistent session + LRU cache + deep_translator fallback
# ─────────────────────────────────────────────────────────────────────────────

_http_session = _requests_lib.Session() if _REQUESTS_AVAILABLE else None
if _REQUESTS_AVAILABLE:
    _http_session.headers.update({"User-Agent": "Mozilla/5.0"})

@lru_cache(maxsize=512)
def _translate_cached(text: str, src: str, tgt: str) -> str:
    if src == tgt:
        return text

    # Strategy 1 — direct requests (fast, reuses connection)
    if _REQUESTS_AVAILABLE and _http_session:
        try:
            url    = "https://translate.googleapis.com/translate_a/single"
            params = {"client": "gtx", "sl": src, "tl": tgt, "dt": "t", "q": text}
            resp   = _http_session.get(url, params=params, timeout=6)
            resp.raise_for_status()
            result = "".join(p[0] for p in resp.json()[0] if p[0]).strip()
            log.debug("translation", "translated_via_requests",
                      src=src, tgt=tgt, chars=len(text))
            return result
        except Exception as e:
            log.warning("translation", "requests_failed", message=str(e))

    # Strategy 2 — deep_translator fallback
    try:
        from deep_translator import GoogleTranslator
        result = GoogleTranslator(source=src, target=tgt).translate(text) or text
        log.debug("translation", "translated_via_deep_translator",
                  src=src, tgt=tgt, chars=len(text))
        return result
    except Exception as e:
        log.error("translation", "all_strategies_failed", exc=e, src=src, tgt=tgt)
        raise RuntimeError(f"Translation failed: {e}") from e


def translate_worker(text, src_lang_key, tgt_lang_key, result_queue):
    _, src = LANGUAGES.get(src_lang_key, ("en", "en"))
    _, tgt = LANGUAGES.get(tgt_lang_key, ("ru", "ru"))
    t0 = time.perf_counter()
    try:
        out = _translate_cached(text, src, tgt)
        ms  = int((time.perf_counter() - t0) * 1000)
        log.info("translation", "complete", src=src, tgt=tgt,
                 input_chars=len(text), latency_ms=ms)
        result_queue.put(("translated", out or text))
    except Exception as e:
        log.error("translation", "worker_exception", exc=e)
        result_queue.put(("status", f"Translation error: {e}"))


# ─────────────────────────────────────────────────────────────────────────────
# Audio helpers
# ─────────────────────────────────────────────────────────────────────────────

def rms(data: bytes) -> float:
    n = len(data) // SAMPLE_WIDTH
    if n == 0:
        return 0.0
    samples = struct.unpack(f"{n}h", data[:n * SAMPLE_WIDTH])
    return math.sqrt(sum(s * s for s in samples) / n)


def get_audio_input_devices():
    if not _PYAUDIO_AVAILABLE:
        log.warning("audio", "pyaudio_not_available")
        return [(-1, "Default Microphone")]
    devices = []
    try:
        pa   = pyaudio.PyAudio()
        seen = set()
        for i in range(pa.get_device_count()):
            info = pa.get_device_info_by_index(i)
            if info.get("maxInputChannels", 0) < 1:
                continue
            name = info["name"]
            if name in seen:
                continue
            seen.add(name)
            nl = name.lower()
            if any(k in nl for k in NVIDIA_KEYWORDS):
                prefix = "🎤 "
            elif any(k in nl for k in VB_KEYWORDS):
                prefix = "★ "
            else:
                prefix = ""
            devices.append((i, f"{prefix}{name}"))
        pa.terminate()
        log.info("audio", "devices_enumerated", count=len(devices),
                 names=[lbl for _, lbl in devices])
    except Exception as e:
        log.error("audio", "device_enumeration_failed", exc=e)
    return devices or [(-1, "Default Microphone")]


def find_device_by_keywords(devices, keywords):
    for _idx, label in devices:
        if any(kw in label.lower() for kw in keywords):
            return label
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Audio capture + VAD
# ─────────────────────────────────────────────────────────────────────────────

class AudioCaptureThread(threading.Thread):
    def __init__(self, device_index, phrase_queue, status_cb, level_cb):
        super().__init__(daemon=True, name="AudioCapture")
        self.device_index      = device_index
        self.phrase_queue      = phrase_queue
        self.status_cb         = status_cb
        self.level_cb          = level_cb
        self._stop_evt         = threading.Event()
        self.energy_threshold  = 300
        self._sensitivity_mult = DEFAULT_SENS
        self._phrases_sent     = 0

    def set_sensitivity(self, mult: float):
        old = self._sensitivity_mult
        self._sensitivity_mult = mult
        log.debug("capture", "sensitivity_changed", old=old, new=mult)

    def stop(self):
        self._stop_evt.set()

    def _flush(self, buf, label="phrase"):
        min_c = int(MIN_PHRASE_SEC * SAMPLE_RATE / CHUNK_SAMPLES)
        if len(buf) >= min_c:
            audio_bytes = b"".join(buf)
            self.phrase_queue.put(audio_bytes)
            self._phrases_sent += 1
            dur_s = len(buf) * CHUNK_SAMPLES / SAMPLE_RATE
            log.info("capture", "phrase_queued",
                     label=label, duration_s=round(dur_s, 2),
                     total_sent=self._phrases_sent,
                     bytes=len(audio_bytes))
        else:
            log.debug("capture", "phrase_too_short_discarded",
                      chunks=len(buf), min_chunks=min_c)

    def run(self):
        log.info("capture", "thread_start",
                 device_index=self.device_index,
                 sensitivity=self._sensitivity_mult)

        if not _PYAUDIO_AVAILABLE:
            msg = "PyAudio not installed — cannot capture audio."
            log.error("capture", "pyaudio_missing")
            self.status_cb(f"ERROR: {msg}")
            return

        pa = pyaudio.PyAudio()
        stream = None
        try:
            kwargs = dict(
                format=pyaudio.paInt16, channels=CHANNELS,
                rate=SAMPLE_RATE, input=True,
                frames_per_buffer=CHUNK_SAMPLES,
            )
            if self.device_index is not None:
                kwargs["input_device_index"] = self.device_index
                info = pa.get_device_info_by_index(self.device_index)
                log.info("capture", "opening_device",
                         index=self.device_index, name=info.get("name"))
            else:
                log.info("capture", "opening_default_device")

            stream = pa.open(**kwargs)
            log.info("capture", "stream_opened",
                     sample_rate=SAMPLE_RATE, chunk_samples=CHUNK_SAMPLES)

        except Exception as e:
            log.error("capture", "stream_open_failed", exc=e,
                      device_index=self.device_index)
            self.status_cb(f"ERROR opening audio device: {e}")
            pa.terminate()
            return

        # ── Calibrate ─────────────────────────────────────────────────────
        self.status_cb("Calibrating ambient noise…")
        cal_count = int(SAMPLE_RATE / CHUNK_SAMPLES)
        cal = []
        for i in range(cal_count):
            if self._stop_evt.is_set():
                stream.close(); pa.terminate(); return
            try:
                cal.append(rms(stream.read(CHUNK_SAMPLES, exception_on_overflow=False)))
            except Exception as e:
                log.warning("capture", "calibration_read_error",
                            chunk=i, message=str(e))

        if cal:
            ambient               = sum(cal) / len(cal)
            self.energy_threshold = max(100, ambient * CAL_MULTIPLIER)
            log.info("capture", "calibration_complete",
                     ambient_rms=round(ambient, 1),
                     threshold=round(self.energy_threshold, 1),
                     multiplier=CAL_MULTIPLIER,
                     sensitivity_mult=self._sensitivity_mult,
                     effective_threshold=round(
                         self.energy_threshold * self._sensitivity_mult, 1))
            self.status_cb(
                f"Ready.  Ambient {ambient:.0f}  "
                f"threshold {self.energy_threshold:.0f}")
        else:
            log.warning("capture", "calibration_no_samples")
            self.status_cb("Ready (calibration failed — default threshold).")

        # ── Main loop ──────────────────────────────────────────────────────
        sil_c    = int(SILENCE_SEC      * SAMPLE_RATE / CHUNK_SAMPLES)
        stream_c = int(STREAM_CHUNK_SEC * SAMPLE_RATE / CHUNK_SAMPLES)
        max_c    = int(MAX_PHRASE_SEC   * SAMPLE_RATE / CHUNK_SAMPLES)

        buf, sil_count, in_speech, chunk_timer = [], 0, False, 0
        read_errors = 0

        log.info("capture", "vad_loop_start",
                 silence_chunks=sil_c, stream_chunks=stream_c, max_chunks=max_c)

        while not self._stop_evt.is_set():
            try:
                data = stream.read(CHUNK_SAMPLES, exception_on_overflow=False)
                read_errors = 0
            except Exception as e:
                read_errors += 1
                log.warning("capture", "read_error",
                            count=read_errors, message=str(e))
                if read_errors > 20:
                    log.error("capture", "too_many_read_errors",
                              count=read_errors)
                    self.status_cb("Audio read error — try restarting.")
                    break
                time.sleep(0.01)
                continue

            level     = rms(data)
            threshold = self.energy_threshold * self._sensitivity_mult
            self.level_cb(level, threshold)

            if level > threshold:
                if not in_speech:
                    in_speech   = True
                    chunk_timer = 0
                    log.debug("capture", "speech_start",
                              level=round(level, 1),
                              threshold=round(threshold, 1))
                    self.status_cb("🎙 Speech…")
                buf.append(data)
                sil_count    = 0
                chunk_timer += 1
                if chunk_timer >= stream_c:
                    log.debug("capture", "mid_speech_flush",
                              chunk_timer=chunk_timer)
                    self._flush(buf, "mid_speech")
                    buf, chunk_timer = [], 0
                elif len(buf) >= max_c:
                    self._flush(buf, "max_length")
                    buf, chunk_timer = [], 0

            elif in_speech:
                sil_count   += 1
                chunk_timer += 1
                buf.append(data)
                if sil_count >= sil_c:
                    log.debug("capture", "silence_end_of_phrase",
                              sil_count=sil_count)
                    self._flush(buf, "silence")
                    buf, sil_count, chunk_timer, in_speech = [], 0, 0, False

        if buf:
            self._flush(buf, "final_flush")

        stream.close()
        pa.terminate()
        log.info("capture", "thread_stop",
                 total_phrases_sent=self._phrases_sent)


# ─────────────────────────────────────────────────────────────────────────────
# Whisper model loader + pre-warm
# ─────────────────────────────────────────────────────────────────────────────

class WhisperModelLoader(threading.Thread):
    def __init__(self, model_size, status_cb):
        super().__init__(daemon=True, name="WhisperLoader")
        self.model_size = model_size
        self.status_cb  = status_cb
        self.model      = None
        self.error      = None
        self.ready      = threading.Event()

    def run(self):
        t0           = time.perf_counter()
        device_label = "GPU" if WHISPER_DEVICE == "cuda" else "CPU"
        log.info("model_loader", "load_start",
                 model=self.model_size, device=WHISPER_DEVICE,
                 compute_type=COMPUTE_TYPE)
        self.status_cb(
            f"Loading Whisper '{self.model_size}' on {device_label}…")
        try:
            from faster_whisper import WhisperModel
            self.model = WhisperModel(
                self.model_size,
                device=WHISPER_DEVICE,
                compute_type=COMPUTE_TYPE,
            )
            load_ms = int((time.perf_counter() - t0) * 1000)
            log.info("model_loader", "load_complete",
                     model=self.model_size, load_ms=load_ms)

            # Pre-warm: eliminates first-inference JIT/alloc spike
            self.status_cb("Pre-warming model…")
            import numpy as np
            dummy    = np.zeros(SAMPLE_RATE, dtype=np.float32)
            segs, _  = self.model.transcribe(
                dummy, language="en", beam_size=1,
                vad_filter=False, without_timestamps=True)
            list(segs)   # consume generator
            warm_ms = int((time.perf_counter() - t0) * 1000) - load_ms
            log.info("model_loader", "prewarm_complete", prewarm_ms=warm_ms)
            self.status_cb(
                f"✔ Whisper '{self.model_size}' ready on {device_label}.")

        except Exception as e:
            self.error = str(e)
            log.error("model_loader", "load_failed", exc=e,
                      model=self.model_size, device=WHISPER_DEVICE)
            self.status_cb(f"ERROR loading Whisper: {e}")
        finally:
            self.ready.set()


# ─────────────────────────────────────────────────────────────────────────────
# Transcription worker  — serialised with a shared lock
# ─────────────────────────────────────────────────────────────────────────────

class TranscriptionWorker(threading.Thread):
    """
    Multiple workers share one phrase_queue and one model instance.
    model_lock ensures only one worker calls model.transcribe() at a time
    (WhisperModel / CTranslate2 is not safe for concurrent inference on
    the same object from multiple Python threads).
    Having multiple workers still helps: while one holds the lock and
    transcribes, others pull the next phrase from the queue so it is
    immediately ready the moment the lock is released.
    """

    def __init__(self, wid, model, model_lock,
                 src_whisper, src_lang_key, tgt_lang_key,
                 phrase_queue, result_queue, status_cb):
        super().__init__(daemon=True, name=f"Transcribe-{wid}")
        self.wid          = wid
        self.model        = model
        self.model_lock   = model_lock   # <-- shared across all workers
        self.src_whisper  = src_whisper
        self.src_lang_key = src_lang_key
        self.tgt_lang_key = tgt_lang_key
        self.phrase_queue = phrase_queue
        self.result_queue = result_queue
        self.status_cb    = status_cb
        self._stop_evt    = threading.Event()
        self._processed   = 0

    def stop(self):
        self._stop_evt.set()
        self.phrase_queue.put(None)   # unblock queue.get

    def run(self):
        import numpy as np
        log.info("transcription", "worker_start",
                 wid=self.wid, language=self.src_whisper)

        while not self._stop_evt.is_set():
            try:
                audio_bytes = self.phrase_queue.get(timeout=0.3)
            except queue.Empty:
                continue
            if audio_bytes is None:
                log.debug("transcription", "worker_sentinel", wid=self.wid)
                break

            dur_s = len(audio_bytes) / (SAMPLE_RATE * SAMPLE_WIDTH)
            t0    = time.perf_counter()
            log.info("transcription", "phrase_received",
                     wid=self.wid, duration_s=round(dur_s, 2),
                     bytes=len(audio_bytes))

            try:
                audio_np = (
                    np.frombuffer(audio_bytes, dtype=np.int16)
                    .astype(np.float32) / 32768.0
                )

                # ── Serialise inference ────────────────────────────────────
                wait_t = time.perf_counter()
                with self.model_lock:
                    waited_ms = int((time.perf_counter() - wait_t) * 1000)
                    if waited_ms > 50:
                        log.debug("transcription", "lock_wait",
                                  wid=self.wid, waited_ms=waited_ms)
                    infer_t  = time.perf_counter()
                    segments, info = self.model.transcribe(
                        audio_np,
                        language=self.src_whisper,
                        task="transcribe",
                        beam_size=1,
                        best_of=1,
                        temperature=0.0,
                        vad_filter=False,
                        condition_on_previous_text=False,
                        without_timestamps=True,
                    )
                    text     = " ".join(seg.text for seg in segments).strip()
                    infer_ms = int((time.perf_counter() - infer_t) * 1000)

                total_ms = int((time.perf_counter() - t0) * 1000)
                self._processed += 1

                log.info("transcription", "phrase_transcribed",
                         wid=self.wid,
                         text=text,
                         language_detected=getattr(info, "language", "?"),
                         language_prob=round(
                             getattr(info, "language_probability", 0), 3),
                         audio_s=round(dur_s, 2),
                         infer_ms=infer_ms,
                         total_ms=total_ms,
                         total_processed=self._processed)

                if text:
                    self.result_queue.put(("heard", text))
                    self.result_queue.put(
                        ("translate", (text, self.src_lang_key, self.tgt_lang_key)))
                else:
                    log.debug("transcription", "empty_result",
                              wid=self.wid, audio_s=round(dur_s, 2))

            except Exception as e:
                log.error("transcription", "inference_error",
                          exc=e, wid=self.wid)
                self.result_queue.put(("status", f"Transcription error: {e}"))

        log.info("transcription", "worker_stop",
                 wid=self.wid, total_processed=self._processed)


# ─────────────────────────────────────────────────────────────────────────────
# Main app
# ─────────────────────────────────────────────────────────────────────────────

class InterpreterApp(ctk.CTk):

    def __init__(self):
        super().__init__()
        self.title("Voice Interpreter")
        self.geometry("940x740")
        self.minsize(760, 580)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self.result_queue   = queue.Queue()
        self.phrase_queue   = queue.Queue()
        self._capture_thr   = None
        self._workers       = []
        self._model_lock    = threading.Lock()   # shared across workers
        self._model_loader  = None
        self._whisper_model = None
        self.is_listening   = False
        self._active_mode   = None

        self.tts = None
        if _TTS_AVAILABLE:
            try:
                self.tts = pyttsx3.init()
                log.info("ui", "tts_initialised")
            except Exception as e:
                log.warning("ui", "tts_init_failed", message=str(e))

        self.audio_devices = get_audio_input_devices()
        self._device_map   = {lbl: idx for idx, lbl in self.audio_devices}
        device_labels      = [lbl for _, lbl in self.audio_devices]

        nvidia_lbl = find_device_by_keywords(self.audio_devices, NVIDIA_KEYWORDS)
        vb_lbl     = find_device_by_keywords(self.audio_devices, VB_KEYWORDS)

        log.info("ui", "devices_selected",
                 nvidia=nvidia_lbl, vb_audio=vb_lbl)

        self._mode_state = [
            [nvidia_lbl or (device_labels[0] if device_labels else ""), "English", "Russian"],
            [vb_lbl     or (device_labels[0] if device_labels else ""), "Russian", "English"],
        ]

        self.device_var      = ctk.StringVar(value=self._mode_state[0][0])
        self.model_var       = ctk.StringVar(value=_DEFAULT_MODEL)
        self.sensitivity_var = ctk.DoubleVar(value=DEFAULT_SENS)
        self.src_var         = ctk.StringVar(value="English")
        self.tgt_var         = ctk.StringVar(value="Russian")

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(4, weight=1)

        self._build_header()
        self._build_quick_switch()
        self._build_controls(device_labels)
        self._build_meter()
        self._build_text_area()
        self._build_status_bar()

        self._apply_mode(0, switch_source=True)
        self._preload_model()
        self.after(80, self._poll_queue)

        log.info("ui", "app_started",
                 whisper_device=WHISPER_DEVICE,
                 num_workers=NUM_WORKERS,
                 default_model=_DEFAULT_MODEL,
                 log_file=str(_LOG_PATH))

    # ── Model ──────────────────────────────────────────────────────────────

    def _preload_model(self):
        self._whisper_model = None
        model_size = MODELS[self.model_var.get()]
        log.info("ui", "model_preload_requested", model=model_size)
        self._model_loader = WhisperModelLoader(
            model_size=model_size,
            status_cb=lambda m: self.result_queue.put(("status", m)),
        )
        self._model_loader.start()

    def _reload_model_if_changed(self):
        if self.is_listening:
            self._stop_session()
        self._whisper_model = None
        self._preload_model()

    # ── UI builders ────────────────────────────────────────────────────────

    def _build_header(self):
        hdr = ctk.CTkFrame(self, corner_radius=0, fg_color=("gray85","gray17"))
        hdr.grid(row=0, column=0, sticky="ew")
        hdr.grid_columnconfigure(0, weight=1)

        title_row = ctk.CTkFrame(hdr, fg_color="transparent")
        title_row.grid(row=0, column=0, pady=(14,2))
        ctk.CTkLabel(title_row, text="🎙  Voice Interpreter",
                     font=ctk.CTkFont(size=22, weight="bold")).grid(row=0, column=0)
        badge_text  = " GPU " if WHISPER_DEVICE == "cuda" else " CPU "
        badge_color = "#27AE60" if WHISPER_DEVICE == "cuda" else "#2980B9"
        ctk.CTkLabel(title_row, text=badge_text,
                     font=ctk.CTkFont(size=10, weight="bold"),
                     fg_color=badge_color, corner_radius=4,
                     text_color="white").grid(row=0, column=1, padx=(10,0))

        ctk.CTkLabel(hdr,
                     text="Powered by Whisper AI  ·  Bidirectional real-time translation",
                     font=ctk.CTkFont(size=12),
                     text_color=("gray50","gray60")).grid(row=1, column=0, pady=(0,12))

    def _build_quick_switch(self):
        qs = ctk.CTkFrame(self, fg_color=("gray88","gray20"), corner_radius=10)
        qs.grid(row=1, column=0, sticky="ew", padx=20, pady=(14,0))
        qs.grid_columnconfigure(0, weight=1)
        qs.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(qs, text="QUICK SWITCH",
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=("gray50","gray55")).grid(
            row=0, column=0, columnspan=2, pady=(8,4))
        self._mode_btns = []
        for col, (label, emoji, src, tgt) in enumerate([
            ("My Voice", "🎤", "English", "Russian"),
            ("Friend",   "🔊", "Russian", "English"),
        ]):
            btn = ctk.CTkButton(
                qs,
                text=f"{emoji}  {label}\n{src} → {tgt}",
                font=ctk.CTkFont(size=14, weight="bold"),
                height=68, corner_radius=8,
                fg_color=COL_INACTIVE, hover_color=COL_IN_HOVER,
                command=lambda i=col: self._on_mode_btn(i),
            )
            px = (12, 6) if col == 0 else (6, 12)
            btn.grid(row=1, column=col, sticky="ew", padx=px, pady=(0,12))
            self._mode_btns.append(btn)

    def _build_controls(self, device_labels):
        outer = ctk.CTkFrame(self, fg_color="transparent")
        outer.grid(row=2, column=0, sticky="ew", padx=20, pady=(10,0))
        outer.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(outer, text="Audio source:", width=140, anchor="w",
                     font=ctk.CTkFont(size=13)).grid(row=0, column=0, sticky="w", pady=2)
        r0 = ctk.CTkFrame(outer, fg_color="transparent")
        r0.grid(row=0, column=1, sticky="w")
        self.device_menu = ctk.CTkOptionMenu(
            r0, variable=self.device_var, values=device_labels, width=340,
            command=self._on_manual_device_change)
        self.device_menu.grid(row=0, column=0)
        ctk.CTkButton(r0, text="⟳", width=34,
                      fg_color=("gray75","gray30"), hover_color=("gray65","gray40"),
                      text_color=("gray10","gray90"),
                      command=self._refresh_devices).grid(row=0, column=1, padx=(8,0))

        ctk.CTkLabel(outer, text="Translate:", width=140, anchor="w",
                     font=ctk.CTkFont(size=13)).grid(row=1, column=0, sticky="w", pady=2)
        r1 = ctk.CTkFrame(outer, fg_color="transparent")
        r1.grid(row=1, column=1, sticky="w")
        lang_names = sorted(LANGUAGES.keys())
        self.src_menu = ctk.CTkOptionMenu(
            r1, variable=self.src_var, values=lang_names, width=155,
            command=self._on_manual_lang_change)
        self.src_menu.grid(row=0, column=0)
        ctk.CTkLabel(r1, text="  →  ",
                     font=ctk.CTkFont(size=16, weight="bold")).grid(row=0, column=1)
        self.tgt_menu = ctk.CTkOptionMenu(
            r1, variable=self.tgt_var, values=lang_names, width=155,
            command=self._on_manual_lang_change)
        self.tgt_menu.grid(row=0, column=2)

        ctk.CTkLabel(outer, text="Model:", width=140, anchor="w",
                     font=ctk.CTkFont(size=13)).grid(row=2, column=0, sticky="w", pady=(6,2))
        r2 = ctk.CTkFrame(outer, fg_color="transparent")
        r2.grid(row=2, column=1, sticky="ew", pady=(6,2))
        self.model_menu = ctk.CTkOptionMenu(
            r2, variable=self.model_var, values=list(MODELS.keys()), width=230,
            command=lambda _: self._reload_model_if_changed())
        self.model_menu.grid(row=0, column=0, padx=(0,20))
        ctk.CTkLabel(r2, text="Sensitivity:",
                     font=ctk.CTkFont(size=13)).grid(row=0, column=1)
        self.sens_slider = ctk.CTkSlider(
            r2, from_=0.1, to=1.5, variable=self.sensitivity_var,
            width=160, command=self._on_sensitivity)
        self.sens_slider.grid(row=0, column=2, padx=(8,4))
        self.sens_label = ctk.CTkLabel(r2, text=f"{DEFAULT_SENS}×",
                                       font=ctk.CTkFont(size=12), width=36)
        self.sens_label.grid(row=0, column=3)

        btns = ctk.CTkFrame(outer, fg_color="transparent")
        btns.grid(row=3, column=0, columnspan=2, sticky="e", pady=(10,0))
        self.start_btn = ctk.CTkButton(
            btns, text="▶  Start Listening", width=160,
            command=self._toggle_listening)
        self.start_btn.grid(row=0, column=0, padx=(0,8))
        ctk.CTkButton(btns, text="🔊  Read Aloud", width=130,
                      fg_color=("gray75","gray30"), hover_color=("gray65","gray40"),
                      text_color=("gray10","gray90"),
                      command=self._speak_translation).grid(row=0, column=1, padx=(0,8))
        ctk.CTkButton(btns, text="Clear", width=70,
                      fg_color=("gray75","gray30"), hover_color=("gray65","gray40"),
                      text_color=("gray10","gray90"),
                      command=self._clear).grid(row=0, column=2)

    def _build_meter(self):
        mf = ctk.CTkFrame(self, fg_color="transparent")
        mf.grid(row=3, column=0, sticky="ew", padx=20, pady=(8,0))
        mf.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(mf, text="Input level:",
                     font=ctk.CTkFont(size=11),
                     text_color=("gray50","gray55"),
                     width=75, anchor="w").grid(row=0, column=0, sticky="w")
        self.level_bar = ctk.CTkProgressBar(mf, height=14, corner_radius=4)
        self.level_bar.set(0)
        self.level_bar.grid(row=0, column=1, sticky="ew", padx=(4,8))
        self.level_text = ctk.CTkLabel(mf, text="—",
                                       font=ctk.CTkFont(size=10),
                                       text_color=("gray50","gray55"),
                                       width=130, anchor="w")
        self.level_text.grid(row=0, column=2)

    def _build_text_area(self):
        frame = ctk.CTkFrame(self, fg_color="transparent")
        frame.grid(row=4, column=0, sticky="nsew", padx=20, pady=(10,0))
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_columnconfigure(1, weight=1)
        frame.grid_rowconfigure(1, weight=1)
        self.heard_label = ctk.CTkLabel(frame, text="Heard in English",
                                        font=ctk.CTkFont(size=12, weight="bold"))
        self.heard_label.grid(row=0, column=0, sticky="w", padx=4, pady=(0,4))
        self.translated_label = ctk.CTkLabel(frame, text="Translation → Russian",
                                             font=ctk.CTkFont(size=12, weight="bold"))
        self.translated_label.grid(row=0, column=1, sticky="w", padx=(12,4), pady=(0,4))
        self.heard_box = ctk.CTkTextbox(
            frame, wrap="word", font=ctk.CTkFont(size=14))
        self.heard_box.grid(row=1, column=0, sticky="nsew", padx=(0,6))
        self.translated_box = ctk.CTkTextbox(
            frame, wrap="word", font=ctk.CTkFont(size=14))
        self.translated_box.grid(row=1, column=1, sticky="nsew", padx=(6,0))

    def _build_status_bar(self):
        self.status_var = ctk.StringVar(value="Loading Whisper model…")
        ctk.CTkLabel(self, textvariable=self.status_var,
                     font=ctk.CTkFont(size=11),
                     text_color=("gray45","gray55"), anchor="w").grid(
            row=5, column=0, sticky="ew", padx=22, pady=(4,10))

    # ── Level meter ────────────────────────────────────────────────────────

    def _on_level(self, level, threshold):
        self.result_queue.put(("level", (level, threshold)))

    def _update_meter(self, level, threshold):
        ceiling  = max(threshold * 4, 800)
        fraction = min(level / ceiling, 1.0)
        self.level_bar.set(fraction)
        active = level > threshold
        self.level_bar.configure(
            progress_color="#27AE60" if active else "#2E86C1")
        self.level_text.configure(
            text=f"{int(fraction*100):3d}%  "
                 f"[{'▐ SPEECH ▌' if active else '  quiet  '}]")

    # ── Mode switching ─────────────────────────────────────────────────────

    def _on_mode_btn(self, mode_idx):
        log.info("ui", "mode_switch", mode=mode_idx)
        if self._active_mode is not None:
            self._mode_state[self._active_mode] = [
                self.device_var.get(), self.src_var.get(), self.tgt_var.get()]
        self._apply_mode(mode_idx, switch_source=True)

    def _apply_mode(self, mode_idx, switch_source=False):
        was = self.is_listening
        if was: self._stop_session(keep_mode=True)
        self._active_mode = mode_idx
        device_lbl, src_lang, tgt_lang = self._mode_state[mode_idx]
        if switch_source and device_lbl:
            self.device_var.set(device_lbl)
        self.src_var.set(src_lang)
        self.tgt_var.set(tgt_lang)
        self.heard_label.configure(text=f"Heard in {src_lang}")
        self.translated_label.configure(text=f"Translation → {tgt_lang}")
        colours = [(COL_MY_VOICE, COL_MY_HOVER), (COL_FRIEND, COL_FR_HOVER)]
        for i, btn in enumerate(self._mode_btns):
            if i == mode_idx:
                btn.configure(fg_color=colours[i][0], hover_color=colours[i][1])
            else:
                btn.configure(fg_color=COL_INACTIVE, hover_color=COL_IN_HOVER)
        if was: self._start_session()

    def _on_manual_device_change(self, _=None):
        log.info("ui", "manual_device_change", device=self.device_var.get())
        if self.is_listening: self._stop_session()

    def _on_manual_lang_change(self, _=None):
        self.heard_label.configure(text=f"Heard in {self.src_var.get()}")
        self.translated_label.configure(text=f"Translation → {self.tgt_var.get()}")
        if self.is_listening: self._stop_session()

    def _refresh_devices(self):
        if self.is_listening: self._stop_session()
        self.audio_devices = get_audio_input_devices()
        self._device_map   = {lbl: idx for idx, lbl in self.audio_devices}
        labels = [lbl for _, lbl in self.audio_devices]
        self.device_menu.configure(values=labels)
        if self.device_var.get() not in labels:
            self.device_var.set(labels[0] if labels else "")
        nvidia_lbl = find_device_by_keywords(self.audio_devices, NVIDIA_KEYWORDS)
        vb_lbl     = find_device_by_keywords(self.audio_devices, VB_KEYWORDS)
        if nvidia_lbl: self._mode_state[0][0] = nvidia_lbl
        if vb_lbl:     self._mode_state[1][0] = vb_lbl
        self.status_var.set(f"Refreshed — {len(labels)} device(s) found.")

    def _set_controls_state(self, state):
        for w in (self.device_menu, self.src_menu, self.tgt_menu,
                  self.model_menu, self.sens_slider):
            w.configure(state=state)

    # ── Session ────────────────────────────────────────────────────────────

    def _toggle_listening(self):
        if self.is_listening: self._stop_session()
        else: self._start_session()

    def _start_session(self):
        if self._model_loader and not self._model_loader.ready.is_set():
            self.status_var.set("⏳ Loading Whisper model — please wait…")
            log.debug("ui", "start_deferred_model_not_ready")
            self.after(600, self._start_session)
            return

        if self._whisper_model is None and self._model_loader:
            if self._model_loader.error:
                msg = f"Cannot start: {self._model_loader.error}"
                self.status_var.set(msg)
                log.error("ui", "start_aborted_model_error",
                          error=self._model_loader.error)
                return
            self._whisper_model = self._model_loader.model

        if self._whisper_model is None:
            self.status_var.set("Whisper model unavailable — check log.")
            log.error("ui", "start_aborted_no_model")
            return

        src_key        = self.src_var.get()
        tgt_key        = self.tgt_var.get()
        src_whisper, _ = LANGUAGES.get(src_key, ("en","en"))
        dev_label      = self.device_var.get()
        dev_idx        = self._device_map.get(dev_label, -1)
        if dev_idx == -1: dev_idx = None

        log.info("ui", "session_start",
                 device=dev_label, device_idx=dev_idx,
                 src=src_key, tgt=tgt_key,
                 model=self.model_var.get(),
                 sensitivity=round(self.sensitivity_var.get(), 2),
                 num_workers=NUM_WORKERS)

        self.is_listening = True
        self.start_btn.configure(text="⏹  Stop Listening",
                                 fg_color=COL_STOP, hover_color=COL_STOP_HOV)
        self._set_controls_state("disabled")

        self.phrase_queue = queue.Queue()

        self._capture_thr = AudioCaptureThread(
            device_index=dev_idx,
            phrase_queue=self.phrase_queue,
            status_cb=lambda m: self.result_queue.put(("status", m)),
            level_cb=self._on_level,
        )
        self._capture_thr.set_sensitivity(round(self.sensitivity_var.get(), 2))
        self._capture_thr.start()

        self._workers = []
        for wid in range(NUM_WORKERS):
            w = TranscriptionWorker(
                wid=wid,
                model=self._whisper_model,
                model_lock=self._model_lock,
                src_whisper=src_whisper,
                src_lang_key=src_key,
                tgt_lang_key=tgt_key,
                phrase_queue=self.phrase_queue,
                result_queue=self.result_queue,
                status_cb=lambda m: self.result_queue.put(("status", m)),
            )
            w.start()
            self._workers.append(w)

    def _stop_session(self, keep_mode=False):
        log.info("ui", "session_stop", keep_mode=keep_mode)
        self.is_listening = False
        if self._capture_thr:
            self._capture_thr.stop(); self._capture_thr = None
        for w in self._workers:
            w.stop()
        self._workers = []
        self.start_btn.configure(text="▶  Start Listening",
                                 fg_color=["#3B8ED0","#1F6AA5"],
                                 hover_color=["#3281BC","#1A5C8F"])
        self._set_controls_state("normal")
        self.level_bar.set(0)
        self.level_text.configure(text="—")
        if not keep_mode:
            self.status_var.set("Stopped.")

    # ── TTS / Clear ────────────────────────────────────────────────────────

    def _speak_translation(self):
        if not self.tts:
            self.status_var.set("TTS not available."); return
        text = self.translated_box.get("1.0","end-1c").strip()
        if not text:
            self.status_var.set("Nothing to read."); return
        def _run():
            try: self.tts.say(text); self.tts.runAndWait()
            except Exception as e:
                log.warning("tts", "speak_failed", message=str(e))
        threading.Thread(target=_run, daemon=True).start()

    def _clear(self):
        log.info("ui", "clear")
        if self.is_listening: self._stop_session()
        self.heard_box.delete("1.0","end")
        self.translated_box.delete("1.0","end")
        self.status_var.set("Cleared.")

    def _on_sensitivity(self, val):
        v = round(float(val), 2)
        self.sens_label.configure(text=f"{v}×")
        if self._capture_thr:
            self._capture_thr.set_sensitivity(v)

    def _on_close(self):
        log.info("ui", "app_closing")
        if self.is_listening: self._stop_session()
        log.close()
        self.destroy()

    # ── Queue poll ─────────────────────────────────────────────────────────

    def _poll_queue(self):
        try:
            while True:
                kind, data = self.result_queue.get_nowait()
                if kind == "heard":
                    self._append(self.heard_box, data)
                elif kind == "translate":
                    text, sk, tk = data
                    threading.Thread(
                        target=translate_worker,
                        args=(text, sk, tk, self.result_queue),
                        daemon=True).start()
                elif kind == "translated":
                    self._append(self.translated_box, data)
                    self.status_var.set(
                        "Listening…" if self.is_listening else "Done.")
                elif kind == "status":
                    self.status_var.set(data)
                elif kind == "level":
                    self._update_meter(*data)
        except queue.Empty:
            pass
        self.after(80, self._poll_queue)

    @staticmethod
    def _append(box, text):
        cur = box.get("1.0","end-1c")
        box.insert("end", ("\n" if cur else "") + text)
        box.see("end")


if __name__ == "__main__":
    try:
        app = InterpreterApp()
        app.mainloop()
    except Exception as e:
        log.error("ui", "fatal_crash", exc=e)
        raise
    finally:
        log.close()
