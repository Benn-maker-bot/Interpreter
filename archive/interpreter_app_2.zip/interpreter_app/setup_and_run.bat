@echo off
title Voice Interpreter Setup
color 0A
echo.
echo ============================================
echo  Voice Interpreter - Setup
echo ============================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found.
    echo Install Python 3.9+ from https://python.org
    echo Tick Add Python to PATH during install.
    pause
    exit /b 1
)
echo [OK] Python found.
echo.
echo Installing packages...
echo.

pip install customtkinter deep-translator pyttsx3 pyaudio numpy --quiet
if errorlevel 1 (
    echo PyAudio failed, trying fallback...
    pip install pipwin --quiet
    pipwin install pyaudio --quiet
)

echo.
echo Installing faster-whisper...
pip install faster-whisper --quiet

echo.
echo [OK] All packages installed.
echo.
echo Starting Voice Interpreter...
echo.
echo Note: The app will download the Whisper model on first launch.
echo This is a one-time download and will be cached for future use.
echo.
python interpreter.py
pause
