"""
Voice Interpreter — low-latency edition.

Latency fixes:
  1. Mid-speech chunking: flushes every STREAM_CHUNK_SEC even while speaker
     is still talking — no waiting for a long sentence to finish.
  2. beam_size=1 (greedy decoding) — ~4× faster than beam_size=5 on CPU,
     accuracy loss is negligible for Russian/English at normal speaking pace.
  3. Two parallel transcription workers share one phrase queue — while
     worker A transcribes chunk N, worker B is already processing chunk N+1.
  4. Silence threshold reduced to 0.35 s — phrases are submitted sooner.
  5. Whisper's internal vad_filter disabled — we supply pre-filtered audio
     so the extra analysis pass is wasted work.
"""

import queue
import threading
import time
import struct
import math

import customtkinter as ctk
from deep_translator import GoogleTranslator

try:
    import pyaudio
    _PYAUDIO_AVAILABLE = True
except ImportError:
    _PYAUDIO_AVAILABLE = False

try:
    import pyttsx3
    _TTS_AVAILABLE = True
except Exception:
    _TTS_AVAILABLE = False

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# ── Audio / VAD constants ──────────────────────────────────────────────────────
SAMPLE_RATE      = 16_000
CHUNK_SAMPLES    = 512            # ~32 ms per read
CHANNELS         = 1
SAMPLE_WIDTH     = 2              # 16-bit PCM
SILENCE_SEC      = 0.35           # silence gap that ends a phrase  (was 0.65)
STREAM_CHUNK_SEC = 2.5            # flush mid-speech every N seconds
MAX_PHRASE_SEC   = 7              # hard cap on phrase length         (was 30)
MIN_PHRASE_SEC   = 0.15           # ignore bursts shorter than this

NUM_WORKERS      = 2              # parallel Whisper transcription threads

VB_KEYWORDS      = ["cable output", "vb-audio", "vb audio", "voicemeeter", "virtual cable"]
NVIDIA_KEYWORDS  = ["nvidia", "broadcast", "rtx voice"]

MODELS = {
    "Tiny  — fastest":          "tiny",
    "Small — recommended ✓":   "small",
    "Medium — most accurate":   "medium",
}
DEFAULT_MODEL = "Small — recommended ✓"

LANGUAGES = {
    "English":            ("en", "en"),
    "Russian":            ("ru", "ru"),
    "Arabic":             ("ar", "ar"),
    "Chinese (Mandarin)": ("zh", "zh-CN"),
    "Dutch":              ("nl", "nl"),
    "French":             ("fr", "fr"),
    "German":             ("de", "de"),
    "Greek":              ("el", "el"),
    "Hindi":              ("hi", "hi"),
    "Italian":            ("it", "it"),
    "Japanese":           ("ja", "ja"),
    "Korean":             ("ko", "ko"),
    "Polish":             ("pl", "pl"),
    "Portuguese":         ("pt", "pt"),
    "Spanish":            ("es", "es"),
    "Turkish":            ("tr", "tr"),
    "Ukrainian":          ("uk", "uk"),
}

COL_MY_VOICE = ("#1A6B3A", "#1A6B3A")
COL_MY_HOVER = ("#155730", "#155730")
COL_FRIEND   = ("#1A4A7A", "#1A4A7A")
COL_FR_HOVER = ("#153D66", "#153D66")
COL_INACTIVE = ("gray30",  "gray25")
COL_IN_HOVER = ("gray40",  "gray35")
COL_STOP     = "#C0392B"
COL_STOP_HOV = "#A93226"


# ─────────────────────────────────────────────────────────────────────────────
# Audio helpers
# ─────────────────────────────────────────────────────────────────────────────

def rms(data: bytes) -> float:
    n = len(data) // SAMPLE_WIDTH
    if n == 0:
        return 0.0
    samples = struct.unpack(f"{n}h", data[:n * SAMPLE_WIDTH])
    return math.sqrt(sum(s * s for s in samples) / n)


def get_audio_input_devices():
    if not _PYAUDIO_AVAILABLE:
        return [(-1, "Default Microphone")]
    devices = []
    try:
        pa   = pyaudio.PyAudio()
        seen = set()
        for i in range(pa.get_device_count()):
            info = pa.get_device_info_by_index(i)
            if info.get("maxInputChannels", 0) < 1:
                continue
            name = info["name"]
            if name in seen:
                continue
            seen.add(name)
            nl = name.lower()
            if any(k in nl for k in NVIDIA_KEYWORDS):
                prefix = "🎤 "
            elif any(k in nl for k in VB_KEYWORDS):
                prefix = "★ "
            else:
                prefix = ""
            devices.append((i, f"{prefix}{name}"))
        pa.terminate()
    except Exception:
        pass
    return devices or [(-1, "Default Microphone")]


def find_device_by_keywords(devices, keywords):
    for _idx, label in devices:
        if any(kw in label.lower() for kw in keywords):
            return label
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Audio capture + VAD thread
# ─────────────────────────────────────────────────────────────────────────────

class AudioCaptureThread(threading.Thread):
    """
    Reads audio, applies energy VAD, and posts phrase buffers to phrase_queue.

    Two flush triggers:
      A) Silence gap  ≥ SILENCE_SEC after speech  — normal end-of-phrase
      B) Mid-speech timer ≥ STREAM_CHUNK_SEC       — flush while still speaking
         so Whisper can start on the first half while capture continues.
    """

    def __init__(self, device_index, phrase_queue, status_cb, level_cb):
        super().__init__(daemon=True)
        self.device_index      = device_index
        self.phrase_queue      = phrase_queue
        self.status_cb         = status_cb
        self.level_cb          = level_cb
        self._stop_evt         = threading.Event()
        self.energy_threshold  = 300
        self._sensitivity_mult = 1.0

    def set_sensitivity(self, mult: float):
        self._sensitivity_mult = mult

    def stop(self):
        self._stop_evt.set()

    def _flush(self, buf, label="Phrase"):
        min_chunks = int(MIN_PHRASE_SEC * SAMPLE_RATE / CHUNK_SAMPLES)
        if len(buf) >= min_chunks:
            self.phrase_queue.put(b"".join(buf))
            dur = len(buf) * CHUNK_SAMPLES / SAMPLE_RATE
            self.status_cb(f"{label} sent to Whisper ({dur:.1f}s)…")

    def run(self):
        pa = pyaudio.PyAudio()
        try:
            kwargs = dict(
                format=pyaudio.paInt16, channels=CHANNELS,
                rate=SAMPLE_RATE, input=True,
                frames_per_buffer=CHUNK_SAMPLES,
            )
            if self.device_index is not None:
                kwargs["input_device_index"] = self.device_index
            stream = pa.open(**kwargs)
        except Exception as e:
            self.status_cb(f"ERROR opening audio device: {e}")
            pa.terminate()
            return

        # Auto-calibrate ~1 s ambient
        self.status_cb("Calibrating ambient noise…")
        cal = []
        for _ in range(int(SAMPLE_RATE / CHUNK_SAMPLES)):
            if self._stop_evt.is_set():
                stream.close(); pa.terminate(); return
            try:
                cal.append(rms(stream.read(CHUNK_SAMPLES, exception_on_overflow=False)))
            except Exception:
                pass
        if cal:
            ambient = sum(cal) / len(cal)
            self.energy_threshold = max(150, ambient * 2.0)
            self.status_cb(
                f"Ready. Ambient RMS {ambient:.0f}  threshold {self.energy_threshold:.0f}"
            )
        else:
            self.status_cb("Ready (default threshold).")

        sil_chunks     = int(SILENCE_SEC      * SAMPLE_RATE / CHUNK_SAMPLES)
        stream_chunks  = int(STREAM_CHUNK_SEC * SAMPLE_RATE / CHUNK_SAMPLES)
        max_chunks     = int(MAX_PHRASE_SEC   * SAMPLE_RATE / CHUNK_SAMPLES)

        buf        = []
        sil_count  = 0
        in_speech  = False
        chunk_timer = 0   # counts chunks since last mid-speech flush

        while not self._stop_evt.is_set():
            try:
                data = stream.read(CHUNK_SAMPLES, exception_on_overflow=False)
            except Exception:
                time.sleep(0.01)
                continue

            level     = rms(data)
            threshold = self.energy_threshold * self._sensitivity_mult
            self.level_cb(level, threshold)

            if level > threshold:
                if not in_speech:
                    in_speech   = True
                    chunk_timer = 0
                    self.status_cb("🎙 Speech detected…")
                buf.append(data)
                sil_count    = 0
                chunk_timer += 1

                # ── Mid-speech flush ──────────────────────────────────────
                if chunk_timer >= stream_chunks:
                    self._flush(buf, "Mid-speech chunk")
                    buf         = []
                    chunk_timer = 0
                elif len(buf) >= max_chunks:
                    self._flush(buf, "Max-length chunk")
                    buf         = []
                    chunk_timer = 0

            elif in_speech:
                sil_count   += 1
                chunk_timer += 1
                buf.append(data)

                if sil_count >= sil_chunks:
                    self._flush(buf, "Phrase")
                    buf        = []
                    sil_count  = 0
                    chunk_timer = 0
                    in_speech  = False

        # Flush remainder on stop
        if buf:
            self._flush(buf, "Final")

        stream.close()
        pa.terminate()


# ─────────────────────────────────────────────────────────────────────────────
# Model loader
# ─────────────────────────────────────────────────────────────────────────────

class WhisperModelLoader(threading.Thread):
    def __init__(self, model_size: str, status_cb):
        super().__init__(daemon=True)
        self.model_size = model_size
        self.status_cb  = status_cb
        self.model      = None
        self.error      = None
        self.ready      = threading.Event()

    def run(self):
        try:
            from faster_whisper import WhisperModel
            self.status_cb(f"Loading Whisper '{self.model_size}' model…")
            self.model = WhisperModel(
                self.model_size, device="cpu", compute_type="int8")
            self.status_cb(f"✔ Whisper '{self.model_size}' ready.")
        except Exception as e:
            self.error = str(e)
            self.status_cb(f"ERROR loading model: {e}")
        finally:
            self.ready.set()


# ─────────────────────────────────────────────────────────────────────────────
# Transcription worker  (NUM_WORKERS instances share one phrase_queue)
# ─────────────────────────────────────────────────────────────────────────────

class TranscriptionWorker(threading.Thread):
    """
    Greedy (beam_size=1) transcription for minimum CPU latency.
    No vad_filter — we send pre-filtered audio from our own VAD.
    Multiple workers run in parallel to keep up with incoming phrases.
    """

    def __init__(self, worker_id, model, src_whisper, src_lang_key, tgt_lang_key,
                 phrase_queue, result_queue, status_cb):
        super().__init__(daemon=True)
        self.wid          = worker_id
        self.model        = model
        self.src_whisper  = src_whisper
        self.src_lang_key = src_lang_key
        self.tgt_lang_key = tgt_lang_key
        self.phrase_queue = phrase_queue
        self.result_queue = result_queue
        self.status_cb    = status_cb
        self._stop_evt    = threading.Event()

    def stop(self):
        self._stop_evt.set()
        # Unblock any worker waiting on the queue
        self.phrase_queue.put(None)

    def run(self):
        import numpy as np

        while not self._stop_evt.is_set():
            try:
                audio_bytes = self.phrase_queue.get(timeout=0.4)
            except queue.Empty:
                continue
            if audio_bytes is None:
                break

            try:
                audio_np = (
                    np.frombuffer(audio_bytes, dtype=np.int16)
                    .astype(np.float32) / 32768.0
                )

                # ── Greedy decode — fastest path ──────────────────────────
                segments, _ = self.model.transcribe(
                    audio_np,
                    language=self.src_whisper,
                    task="transcribe",
                    beam_size=1,          # greedy — ~4× faster than beam=5
                    best_of=1,
                    temperature=0.0,
                    vad_filter=False,     # pre-filtered by our VAD
                    condition_on_previous_text=False,
                    without_timestamps=True,
                )
                text = " ".join(seg.text for seg in segments).strip()
                if text:
                    self.result_queue.put(("heard", text))
                    self.result_queue.put(("translate", (text, self.src_lang_key, self.tgt_lang_key)))
            except Exception as e:
                self.status_cb(f"Worker {self.wid} error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# Translation
# ─────────────────────────────────────────────────────────────────────────────

def translate_worker(text, src_lang_key, tgt_lang_key, result_queue):
    _, src_code = LANGUAGES.get(src_lang_key, ("en", "en"))
    _, tgt_code = LANGUAGES.get(tgt_lang_key, ("ru", "ru"))
    try:
        if src_code == tgt_code:
            result_queue.put(("translated", text))
        else:
            out = GoogleTranslator(source=src_code, target=tgt_code).translate(text)
            result_queue.put(("translated", out or text))
    except Exception as e:
        result_queue.put(("status", f"Translation error: {e}"))


# ─────────────────────────────────────────────────────────────────────────────
# Main app
# ─────────────────────────────────────────────────────────────────────────────

class InterpreterApp(ctk.CTk):

    def __init__(self):
        super().__init__()
        self.title("Voice Interpreter")
        self.geometry("940x740")
        self.minsize(760, 580)

        self.result_queue   = queue.Queue()
        self.phrase_queue   = queue.Queue()
        self._capture_thr   = None
        self._workers       = []
        self._model_loader  = None
        self._whisper_model = None
        self.is_listening   = False
        self._active_mode   = None

        self.tts = None
        if _TTS_AVAILABLE:
            try: self.tts = pyttsx3.init()
            except Exception: pass

        self.audio_devices = get_audio_input_devices()
        self._device_map   = {lbl: idx for idx, lbl in self.audio_devices}
        device_labels      = [lbl for _, lbl in self.audio_devices]

        nvidia_lbl = find_device_by_keywords(self.audio_devices, NVIDIA_KEYWORDS)
        vb_lbl     = find_device_by_keywords(self.audio_devices, VB_KEYWORDS)

        self._mode_state = [
            [nvidia_lbl or (device_labels[0] if device_labels else ""), "English", "Russian"],
            [vb_lbl     or (device_labels[0] if device_labels else ""), "Russian", "English"],
        ]

        self.device_var      = ctk.StringVar(value=self._mode_state[0][0])
        self.model_var       = ctk.StringVar(value=DEFAULT_MODEL)
        self.sensitivity_var = ctk.DoubleVar(value=1.0)
        self.src_var         = ctk.StringVar(value="English")
        self.tgt_var         = ctk.StringVar(value="Russian")

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(4, weight=1)

        self._build_header()
        self._build_quick_switch()
        self._build_controls(device_labels)
        self._build_meter()
        self._build_text_area()
        self._build_status_bar()

        self._apply_mode(0, switch_source=True)
        self._preload_model()
        self.after(80, self._poll_queue)

    # ── Model pre-load ─────────────────────────────────────────────────────

    def _preload_model(self):
        self._whisper_model = None
        self._model_loader  = WhisperModelLoader(
            model_size=MODELS[self.model_var.get()],
            status_cb=lambda m: self.result_queue.put(("status", m)),
        )
        self._model_loader.start()

    def _reload_model_if_changed(self):
        if self.is_listening:
            self._stop_session()
        self._whisper_model = None
        self._preload_model()

    # ── UI builders ────────────────────────────────────────────────────────

    def _build_header(self):
        hdr = ctk.CTkFrame(self, corner_radius=0, fg_color=("gray85","gray17"))
        hdr.grid(row=0, column=0, sticky="ew")
        hdr.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(hdr, text="🎙  Voice Interpreter",
                     font=ctk.CTkFont(size=22, weight="bold")).grid(row=0, column=0, pady=(14,2))
        ctk.CTkLabel(hdr,
                     text="Powered by Whisper AI  ·  Bidirectional real-time translation",
                     font=ctk.CTkFont(size=12),
                     text_color=("gray50","gray60")).grid(row=1, column=0, pady=(0,12))

    def _build_quick_switch(self):
        qs = ctk.CTkFrame(self, fg_color=("gray88","gray20"), corner_radius=10)
        qs.grid(row=1, column=0, sticky="ew", padx=20, pady=(14,0))
        qs.grid_columnconfigure(0, weight=1)
        qs.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(qs, text="QUICK SWITCH",
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=("gray50","gray55")).grid(
            row=0, column=0, columnspan=2, pady=(8,4))
        self._mode_btns = []
        for col, (label, emoji, src, tgt) in enumerate([
            ("My Voice",  "🎤", "English", "Russian"),
            ("Friend",    "🔊", "Russian", "English"),
        ]):
            btn = ctk.CTkButton(
                qs,
                text=f"{emoji}  {label}\n{src} → {tgt}",
                font=ctk.CTkFont(size=14, weight="bold"),
                height=68, corner_radius=8,
                fg_color=COL_INACTIVE, hover_color=COL_IN_HOVER,
                command=lambda i=col: self._on_mode_btn(i),
            )
            px = (12, 6) if col == 0 else (6, 12)
            btn.grid(row=1, column=col, sticky="ew", padx=px, pady=(0,12))
            self._mode_btns.append(btn)

    def _build_controls(self, device_labels):
        outer = ctk.CTkFrame(self, fg_color="transparent")
        outer.grid(row=2, column=0, sticky="ew", padx=20, pady=(10,0))
        outer.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(outer, text="Audio source:", width=140, anchor="w",
                     font=ctk.CTkFont(size=13)).grid(row=0, column=0, sticky="w", pady=2)
        r0 = ctk.CTkFrame(outer, fg_color="transparent")
        r0.grid(row=0, column=1, sticky="w")
        self.device_menu = ctk.CTkOptionMenu(
            r0, variable=self.device_var, values=device_labels, width=340,
            command=self._on_manual_device_change)
        self.device_menu.grid(row=0, column=0)
        ctk.CTkButton(r0, text="⟳", width=34,
                      fg_color=("gray75","gray30"), hover_color=("gray65","gray40"),
                      text_color=("gray10","gray90"),
                      command=self._refresh_devices).grid(row=0, column=1, padx=(8,0))

        ctk.CTkLabel(outer, text="Translate:", width=140, anchor="w",
                     font=ctk.CTkFont(size=13)).grid(row=1, column=0, sticky="w", pady=2)
        r1 = ctk.CTkFrame(outer, fg_color="transparent")
        r1.grid(row=1, column=1, sticky="w")
        lang_names = sorted(LANGUAGES.keys())
        self.src_menu = ctk.CTkOptionMenu(
            r1, variable=self.src_var, values=lang_names, width=155,
            command=self._on_manual_lang_change)
        self.src_menu.grid(row=0, column=0)
        ctk.CTkLabel(r1, text="  →  ",
                     font=ctk.CTkFont(size=16, weight="bold")).grid(row=0, column=1)
        self.tgt_menu = ctk.CTkOptionMenu(
            r1, variable=self.tgt_var, values=lang_names, width=155,
            command=self._on_manual_lang_change)
        self.tgt_menu.grid(row=0, column=2)

        ctk.CTkLabel(outer, text="Model:", width=140, anchor="w",
                     font=ctk.CTkFont(size=13)).grid(row=2, column=0, sticky="w", pady=(6,2))
        r2 = ctk.CTkFrame(outer, fg_color="transparent")
        r2.grid(row=2, column=1, sticky="ew", pady=(6,2))
        self.model_menu = ctk.CTkOptionMenu(
            r2, variable=self.model_var, values=list(MODELS.keys()), width=230,
            command=lambda _: self._reload_model_if_changed())
        self.model_menu.grid(row=0, column=0, padx=(0,20))
        ctk.CTkLabel(r2, text="Sensitivity:",
                     font=ctk.CTkFont(size=13)).grid(row=0, column=1)
        self.sens_slider = ctk.CTkSlider(
            r2, from_=0.3, to=2.5, variable=self.sensitivity_var,
            width=150, command=self._on_sensitivity)
        self.sens_slider.grid(row=0, column=2, padx=(8,4))
        self.sens_label = ctk.CTkLabel(r2, text="1.0×",
                                       font=ctk.CTkFont(size=12), width=36)
        self.sens_label.grid(row=0, column=3)

        btns = ctk.CTkFrame(outer, fg_color="transparent")
        btns.grid(row=3, column=0, columnspan=2, sticky="e", pady=(10,0))
        self.start_btn = ctk.CTkButton(
            btns, text="▶  Start Listening", width=160,
            command=self._toggle_listening)
        self.start_btn.grid(row=0, column=0, padx=(0,8))
        ctk.CTkButton(btns, text="🔊  Read Aloud", width=130,
                      fg_color=("gray75","gray30"), hover_color=("gray65","gray40"),
                      text_color=("gray10","gray90"),
                      command=self._speak_translation).grid(row=0, column=1, padx=(0,8))
        ctk.CTkButton(btns, text="Clear", width=70,
                      fg_color=("gray75","gray30"), hover_color=("gray65","gray40"),
                      text_color=("gray10","gray90"),
                      command=self._clear).grid(row=0, column=2)

    def _build_meter(self):
        mf = ctk.CTkFrame(self, fg_color="transparent")
        mf.grid(row=3, column=0, sticky="ew", padx=20, pady=(8,0))
        mf.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(mf, text="Input level:",
                     font=ctk.CTkFont(size=11),
                     text_color=("gray50","gray55"),
                     width=75, anchor="w").grid(row=0, column=0, sticky="w")
        self.level_bar = ctk.CTkProgressBar(mf, height=12, corner_radius=4)
        self.level_bar.set(0)
        self.level_bar.grid(row=0, column=1, sticky="ew", padx=(4,8))
        self.level_text = ctk.CTkLabel(mf, text="—",
                                       font=ctk.CTkFont(size=10),
                                       text_color=("gray50","gray55"),
                                       width=130, anchor="w")
        self.level_text.grid(row=0, column=2)

    def _build_text_area(self):
        frame = ctk.CTkFrame(self, fg_color="transparent")
        frame.grid(row=4, column=0, sticky="nsew", padx=20, pady=(10,0))
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_columnconfigure(1, weight=1)
        frame.grid_rowconfigure(1, weight=1)
        self.heard_label = ctk.CTkLabel(frame, text="Heard in English",
                                        font=ctk.CTkFont(size=12, weight="bold"))
        self.heard_label.grid(row=0, column=0, sticky="w", padx=4, pady=(0,4))
        self.translated_label = ctk.CTkLabel(frame, text="Translation → Russian",
                                             font=ctk.CTkFont(size=12, weight="bold"))
        self.translated_label.grid(row=0, column=1, sticky="w", padx=(12,4), pady=(0,4))
        self.heard_box = ctk.CTkTextbox(frame, wrap="word", font=ctk.CTkFont(size=14))
        self.heard_box.grid(row=1, column=0, sticky="nsew", padx=(0,6))
        self.translated_box = ctk.CTkTextbox(frame, wrap="word", font=ctk.CTkFont(size=14))
        self.translated_box.grid(row=1, column=1, sticky="nsew", padx=(6,0))

    def _build_status_bar(self):
        self.status_var = ctk.StringVar(value="Loading Whisper model…")
        ctk.CTkLabel(self, textvariable=self.status_var,
                     font=ctk.CTkFont(size=11),
                     text_color=("gray45","gray55"), anchor="w").grid(
            row=5, column=0, sticky="ew", padx=22, pady=(4,10))

    # ── Level meter ────────────────────────────────────────────────────────

    def _on_level(self, level, threshold):
        self.result_queue.put(("level", (level, threshold)))

    def _update_meter(self, level, threshold):
        ceiling  = max(threshold * 5, 1000)
        fraction = min(level / ceiling, 1.0)
        self.level_bar.set(fraction)
        active = level > threshold
        self.level_bar.configure(
            progress_color="#27AE60" if active else "#2E86C1")
        self.level_text.configure(
            text=f"{int(fraction*100):3d}%  thr:{threshold:.0f}  "
                 f"[{'SPEECH' if active else 'quiet '}]")

    # ── Mode switching ─────────────────────────────────────────────────────

    def _on_mode_btn(self, mode_idx):
        if self._active_mode is not None:
            self._mode_state[self._active_mode] = [
                self.device_var.get(), self.src_var.get(), self.tgt_var.get()]
        self._apply_mode(mode_idx, switch_source=True)

    def _apply_mode(self, mode_idx, switch_source=False):
        was = self.is_listening
        if was: self._stop_session(keep_mode=True)

        self._active_mode = mode_idx
        device_lbl, src_lang, tgt_lang = self._mode_state[mode_idx]

        if switch_source and device_lbl:
            self.device_var.set(device_lbl)
        self.src_var.set(src_lang)
        self.tgt_var.set(tgt_lang)
        self.heard_label.configure(text=f"Heard in {src_lang}")
        self.translated_label.configure(text=f"Translation → {tgt_lang}")

        colours = [(COL_MY_VOICE, COL_MY_HOVER), (COL_FRIEND, COL_FR_HOVER)]
        for i, btn in enumerate(self._mode_btns):
            if i == mode_idx:
                btn.configure(fg_color=colours[i][0], hover_color=colours[i][1])
            else:
                btn.configure(fg_color=COL_INACTIVE, hover_color=COL_IN_HOVER)

        if was: self._start_session()

    def _on_manual_device_change(self, _=None):
        if self.is_listening: self._stop_session()

    def _on_manual_lang_change(self, _=None):
        self.heard_label.configure(text=f"Heard in {self.src_var.get()}")
        self.translated_label.configure(text=f"Translation → {self.tgt_var.get()}")
        if self.is_listening: self._stop_session()

    def _refresh_devices(self):
        if self.is_listening: self._stop_session()
        self.audio_devices = get_audio_input_devices()
        self._device_map   = {lbl: idx for idx, lbl in self.audio_devices}
        labels = [lbl for _, lbl in self.audio_devices]
        self.device_menu.configure(values=labels)
        if self.device_var.get() not in labels:
            self.device_var.set(labels[0] if labels else "")
        nvidia_lbl = find_device_by_keywords(self.audio_devices, NVIDIA_KEYWORDS)
        vb_lbl     = find_device_by_keywords(self.audio_devices, VB_KEYWORDS)
        if nvidia_lbl: self._mode_state[0][0] = nvidia_lbl
        if vb_lbl:     self._mode_state[1][0] = vb_lbl
        self.status_var.set(f"Refreshed — {len(labels)} device(s) found.")

    def _set_controls_state(self, state):
        for w in (self.device_menu, self.src_menu, self.tgt_menu,
                  self.model_menu, self.sens_slider):
            w.configure(state=state)

    # ── Session ────────────────────────────────────────────────────────────

    def _toggle_listening(self):
        if self.is_listening: self._stop_session()
        else: self._start_session()

    def _start_session(self):
        if self._model_loader and not self._model_loader.ready.is_set():
            self.status_var.set("⏳ Loading Whisper model — please wait…")
            self.after(800, self._start_session)
            return
        if self._whisper_model is None and self._model_loader:
            if self._model_loader.error:
                self.status_var.set(f"Cannot start: {self._model_loader.error}")
                return
            self._whisper_model = self._model_loader.model
        if self._whisper_model is None:
            self.status_var.set("Whisper model unavailable.")
            return

        self.is_listening = True
        self.start_btn.configure(text="⏹  Stop Listening",
                                 fg_color=COL_STOP, hover_color=COL_STOP_HOV)
        self._set_controls_state("disabled")

        dev_idx = self._device_map.get(self.device_var.get(), -1)
        if dev_idx == -1: dev_idx = None

        src_key           = self.src_var.get()
        tgt_key           = self.tgt_var.get()
        src_whisper, _    = LANGUAGES.get(src_key, ("en","en"))

        self.phrase_queue = queue.Queue()

        # Capture thread
        self._capture_thr = AudioCaptureThread(
            device_index=dev_idx,
            phrase_queue=self.phrase_queue,
            status_cb=lambda m: self.result_queue.put(("status", m)),
            level_cb=self._on_level,
        )
        self._capture_thr.set_sensitivity(round(self.sensitivity_var.get(), 1))
        self._capture_thr.start()

        # NUM_WORKERS parallel transcription workers
        self._workers = []
        for wid in range(NUM_WORKERS):
            w = TranscriptionWorker(
                worker_id=wid,
                model=self._whisper_model,
                src_whisper=src_whisper,
                src_lang_key=src_key,
                tgt_lang_key=tgt_key,
                phrase_queue=self.phrase_queue,
                result_queue=self.result_queue,
                status_cb=lambda m: self.result_queue.put(("status", m)),
            )
            w.start()
            self._workers.append(w)

    def _stop_session(self, keep_mode=False):
        self.is_listening = False
        if self._capture_thr:
            self._capture_thr.stop(); self._capture_thr = None
        for w in self._workers:
            w.stop()
        self._workers = []
        self.start_btn.configure(text="▶  Start Listening",
                                 fg_color=["#3B8ED0","#1F6AA5"],
                                 hover_color=["#3281BC","#1A5C8F"])
        self._set_controls_state("normal")
        self.level_bar.set(0)
        self.level_text.configure(text="—")
        if not keep_mode:
            self.status_var.set("Stopped.")

    # ── TTS / Clear ────────────────────────────────────────────────────────

    def _speak_translation(self):
        if not self.tts:
            self.status_var.set("TTS not available."); return
        text = self.translated_box.get("1.0","end-1c").strip()
        if not text:
            self.status_var.set("Nothing to read."); return
        def _run():
            try: self.tts.say(text); self.tts.runAndWait()
            except Exception: pass
        threading.Thread(target=_run, daemon=True).start()

    def _clear(self):
        if self.is_listening: self._stop_session()
        self.heard_box.delete("1.0","end")
        self.translated_box.delete("1.0","end")
        self.status_var.set("Cleared.")

    # ── Sensitivity ────────────────────────────────────────────────────────

    def _on_sensitivity(self, val):
        v = round(float(val), 1)
        self.sens_label.configure(text=f"{v}×")
        if self._capture_thr:
            self._capture_thr.set_sensitivity(v)

    # ── Queue poll ─────────────────────────────────────────────────────────

    def _poll_queue(self):
        try:
            while True:
                kind, data = self.result_queue.get_nowait()
                if kind == "heard":
                    self._append(self.heard_box, data)
                elif kind == "translate":
                    text, sk, tk = data
                    threading.Thread(
                        target=translate_worker,
                        args=(text, sk, tk, self.result_queue),
                        daemon=True).start()
                elif kind == "translated":
                    self._append(self.translated_box, data)
                    self.status_var.set(
                        "Translated. Listening…" if self.is_listening else "Done.")
                elif kind == "status":
                    self.status_var.set(data)
                elif kind == "level":
                    self._update_meter(*data)
        except queue.Empty:
            pass
        self.after(80, self._poll_queue)

    @staticmethod
    def _append(box, text):
        cur = box.get("1.0","end-1c")
        box.insert("end", ("\n" if cur else "") + text)
        box.see("end")


if __name__ == "__main__":
    app = InterpreterApp()
    app.mainloop()
