"""
Voice Interpreter — bidirectional, two-mode edition.

MODE A  "My Voice"    — NVIDIA Broadcast mic  →  English → Russian
MODE B  "Friend"      — VB-Audio CABLE Output  →  Russian → English

One-click switching between modes while listening.
"""

import queue
import threading
import time
import struct
import math

import customtkinter as ctk
from deep_translator import GoogleTranslator

try:
    import pyaudio
    _PYAUDIO_AVAILABLE = True
except ImportError:
    _PYAUDIO_AVAILABLE = False

try:
    import pyttsx3
    _TTS_AVAILABLE = True
except Exception:
    _TTS_AVAILABLE = False

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# ── Audio constants ────────────────────────────────────────────────────────────
SAMPLE_RATE    = 16_000
CHUNK_SAMPLES  = 512
CHANNELS       = 1
SAMPLE_WIDTH   = 2
MAX_PHRASE_SEC = 30
MIN_PHRASE_SEC = 0.25
SILENCE_SEC    = 0.6

# ── Device fingerprints ────────────────────────────────────────────────────────
VB_KEYWORDS      = ["cable output", "vb-audio", "vb audio", "voicemeeter", "virtual cable"]
NVIDIA_KEYWORDS  = ["nvidia", "broadcast", "rtx voice"]

# ── Whisper models ─────────────────────────────────────────────────────────────
MODELS = {
    "Tiny  — fastest":            "tiny",
    "Small — recommended ✓":     "small",
    "Medium — most accurate":     "medium",
}
DEFAULT_MODEL = "Small — recommended ✓"

# ── Supported languages (whisper_code, google_translate_code, display_name) ───
#    These are languages available as BOTH source and target.
LANGUAGES = {
    "English":            ("en", "en"),
    "Russian":            ("ru", "ru"),
    "Arabic":             ("ar", "ar"),
    "Chinese (Mandarin)": ("zh", "zh-CN"),
    "Dutch":              ("nl", "nl"),
    "French":             ("fr", "fr"),
    "German":             ("de", "de"),
    "Greek":              ("el", "el"),
    "Hindi":              ("hi", "hi"),
    "Italian":            ("it", "it"),
    "Japanese":           ("ja", "ja"),
    "Korean":             ("ko", "ko"),
    "Polish":             ("pl", "pl"),
    "Portuguese":         ("pt", "pt"),
    "Spanish":            ("es", "es"),
    "Turkish":            ("tr", "tr"),
    "Ukrainian":          ("uk", "uk"),
}

# ── Pre-defined quick-switch modes ─────────────────────────────────────────────
# Each mode: (label, emoji, device_keyword, src_lang, tgt_lang)
QUICK_MODES = [
    ("My Voice",  "🎤", NVIDIA_KEYWORDS, "English", "Russian"),
    ("Friend",    "🔊", VB_KEYWORDS,     "Russian", "English"),
]


# ─────────────────────────────────────────────────────────────────────────────
# Audio helpers
# ─────────────────────────────────────────────────────────────────────────────

def rms(data: bytes) -> float:
    n = len(data) // SAMPLE_WIDTH
    if n == 0:
        return 0.0
    samples = struct.unpack(f"{n}h", data[:n * SAMPLE_WIDTH])
    return math.sqrt(sum(s * s for s in samples) / n)


def get_audio_input_devices():
    """Return [(device_index, display_label), ...] for every input device."""
    if not _PYAUDIO_AVAILABLE:
        return [(-1, "Default Microphone")]
    devices = []
    try:
        pa   = pyaudio.PyAudio()
        seen = set()
        for i in range(pa.get_device_count()):
            info = pa.get_device_info_by_index(i)
            if info.get("maxInputChannels", 0) < 1:
                continue
            name = info["name"]
            if name in seen:
                continue
            seen.add(name)
            nl = name.lower()
            if any(k in nl for k in NVIDIA_KEYWORDS):
                prefix = "🎤 "
            elif any(k in nl for k in VB_KEYWORDS):
                prefix = "★ "
            else:
                prefix = ""
            devices.append((i, f"{prefix}{name}"))
        pa.terminate()
    except Exception:
        pass
    return devices or [(-1, "Default Microphone")]


def find_device_by_keywords(devices, keywords):
    """Return the label of the first device whose name matches any keyword."""
    for _idx, label in devices:
        if any(kw in label.lower() for kw in keywords):
            return label
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Audio capture + VAD thread
# ─────────────────────────────────────────────────────────────────────────────

class AudioCaptureThread(threading.Thread):
    def __init__(self, device_index, phrase_queue: queue.Queue, status_cb):
        super().__init__(daemon=True)
        self.device_index      = device_index
        self.phrase_queue      = phrase_queue
        self.status_cb         = status_cb
        self._stop_evt         = threading.Event()
        self.energy_threshold  = 300
        self._sensitivity_mult = 1.0

    def set_sensitivity(self, mult: float):
        self._sensitivity_mult = mult

    def stop(self):
        self._stop_evt.set()

    def run(self):
        pa = pyaudio.PyAudio()
        try:
            kwargs = dict(
                format=pyaudio.paInt16, channels=CHANNELS,
                rate=SAMPLE_RATE, input=True,
                frames_per_buffer=CHUNK_SAMPLES,
            )
            if self.device_index is not None:
                kwargs["input_device_index"] = self.device_index
            stream = pa.open(**kwargs)
        except Exception as e:
            self.status_cb(f"Audio device error: {e}")
            pa.terminate()
            return

        # Auto-calibrate ~1 s ambient noise
        self.status_cb("Calibrating…")
        cal = []
        for _ in range(int(SAMPLE_RATE / CHUNK_SAMPLES)):
            if self._stop_evt.is_set():
                stream.close(); pa.terminate(); return
            try:
                cal.append(rms(stream.read(CHUNK_SAMPLES, exception_on_overflow=False)))
            except Exception:
                pass
        if cal:
            self.energy_threshold = max(200, (sum(cal) / len(cal)) * 2.5)

        self.status_cb("Ready — listening…")

        sil_chunks = int(SILENCE_SEC    * SAMPLE_RATE / CHUNK_SAMPLES)
        max_chunks = int(MAX_PHRASE_SEC * SAMPLE_RATE / CHUNK_SAMPLES)
        min_chunks = int(MIN_PHRASE_SEC * SAMPLE_RATE / CHUNK_SAMPLES)

        buf, sil_count, in_speech = [], 0, False

        while not self._stop_evt.is_set():
            try:
                data = stream.read(CHUNK_SAMPLES, exception_on_overflow=False)
            except Exception:
                time.sleep(0.01)
                continue

            loud = rms(data) > self.energy_threshold * self._sensitivity_mult

            if loud:
                if not in_speech:
                    in_speech = True
                    self.status_cb("🎙 Hearing speech…")
                buf.append(data)
                sil_count = 0
            elif in_speech:
                sil_count += 1
                buf.append(data)
                if sil_count >= sil_chunks or len(buf) >= max_chunks:
                    if len(buf) >= min_chunks:
                        self.phrase_queue.put(b"".join(buf))
                    buf, sil_count, in_speech = [], 0, False
                    self.status_cb("Processing…")

        if buf and len(buf) >= min_chunks:
            self.phrase_queue.put(b"".join(buf))

        stream.close()
        pa.terminate()


# ─────────────────────────────────────────────────────────────────────────────
# Whisper transcription thread
# ─────────────────────────────────────────────────────────────────────────────

class TranscriptionThread(threading.Thread):
    def __init__(self, model_size, src_whisper, src_lang_key, tgt_lang_key,
                 phrase_queue, result_queue, status_cb):
        super().__init__(daemon=True)
        self.model_size   = model_size
        self.src_whisper  = src_whisper    # e.g. "en" or "ru"
        self.src_lang_key = src_lang_key   # e.g. "English"
        self.tgt_lang_key = tgt_lang_key   # e.g. "Russian"
        self.phrase_queue = phrase_queue
        self.result_queue = result_queue
        self.status_cb    = status_cb
        self._stop_evt    = threading.Event()

    def stop(self):
        self._stop_evt.set()
        self.phrase_queue.put(None)

    def run(self):
        self.status_cb(f"Loading Whisper '{self.model_size}'…")
        try:
            from faster_whisper import WhisperModel
            model = WhisperModel(self.model_size, device="cpu", compute_type="int8")
        except Exception as e:
            self.status_cb(f"Whisper load error: {e}")
            return

        self.status_cb("Whisper ready — listening…")

        while not self._stop_evt.is_set():
            try:
                audio_bytes = self.phrase_queue.get(timeout=0.5)
            except queue.Empty:
                continue
            if audio_bytes is None:
                break
            try:
                import numpy as np
                audio_np = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32) / 32768.0
                segments, _ = model.transcribe(
                    audio_np,
                    language=self.src_whisper,
                    task="transcribe",
                    beam_size=5,
                    vad_filter=True,
                    vad_parameters=dict(min_silence_duration_ms=300, speech_pad_ms=200),
                    condition_on_previous_text=False,
                )
                text = " ".join(seg.text for seg in segments).strip()
                if text:
                    self.result_queue.put(("heard", text))
                    self.result_queue.put(("translate", (text, self.src_lang_key, self.tgt_lang_key)))
            except Exception as e:
                self.status_cb(f"Transcription error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# Translation worker
# ─────────────────────────────────────────────────────────────────────────────

def translate_worker(text, src_lang_key, tgt_lang_key, result_queue):
    _, src_code = LANGUAGES.get(src_lang_key, ("en", "en"))
    _, tgt_code = LANGUAGES.get(tgt_lang_key, ("ru", "ru"))
    try:
        if src_code == tgt_code:
            result_queue.put(("translated", text))
        else:
            out = GoogleTranslator(source=src_code, target=tgt_code).translate(text)
            result_queue.put(("translated", out or text))
    except Exception as e:
        result_queue.put(("status", f"Translation error: {e}"))


# ─────────────────────────────────────────────────────────────────────────────
# Main app
# ─────────────────────────────────────────────────────────────────────────────

# Colour constants
COL_MY_VOICE_ACTIVE  = ("#1A6B3A", "#1A6B3A")   # green — my voice mode
COL_MY_VOICE_HOVER   = ("#155730", "#155730")
COL_FRIEND_ACTIVE    = ("#1A4A7A", "#1A4A7A")   # blue  — friend mode
COL_FRIEND_HOVER     = ("#153D66", "#153D66")
COL_INACTIVE         = ("gray30",  "gray25")
COL_INACTIVE_HOVER   = ("gray40",  "gray35")
COL_STOP             = "#C0392B"
COL_STOP_HOVER       = "#A93226"


class InterpreterApp(ctk.CTk):

    def __init__(self):
        super().__init__()
        self.title("Voice Interpreter")
        self.geometry("920x700")
        self.minsize(740, 560)

        self.result_queue    = queue.Queue()
        self.phrase_queue    = queue.Queue()
        self._capture_thr    = None
        self._transcribe_thr = None
        self.is_listening    = False
        self._active_mode    = None     # 0 = My Voice, 1 = Friend

        self.tts = None
        if _TTS_AVAILABLE:
            try: self.tts = pyttsx3.init()
            except Exception: pass

        # Devices
        self.audio_devices = get_audio_input_devices()
        self._device_map   = {lbl: idx for idx, lbl in self.audio_devices}
        device_labels      = [lbl for _, lbl in self.audio_devices]

        # Default device selections per mode
        nvidia_lbl = find_device_by_keywords(self.audio_devices, NVIDIA_KEYWORDS)
        vb_lbl     = find_device_by_keywords(self.audio_devices, VB_KEYWORDS)

        self.device_var = ctk.StringVar(
            value=nvidia_lbl or (device_labels[0] if device_labels else ""))
        self.model_var       = ctk.StringVar(value=DEFAULT_MODEL)
        self.sensitivity_var = ctk.DoubleVar(value=1.0)

        # Per-mode state: (device_label, src_lang, tgt_lang)
        self._mode_state = [
            [nvidia_lbl or (device_labels[0] if device_labels else ""), "English", "Russian"],
            [vb_lbl     or (device_labels[0] if device_labels else ""), "Russian", "English"],
        ]

        self.src_var = ctk.StringVar(value=self._mode_state[0][1])
        self.tgt_var = ctk.StringVar(value=self._mode_state[0][2])

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(4, weight=1)

        self._build_header()
        self._build_quick_switch()
        self._build_controls(device_labels)
        self._build_text_area()
        self._build_status_bar()

        # Highlight My Voice as selected by default
        self._apply_mode(0, switch_source=True)

        self.after(80, self._poll_queue)

    # ── UI builders ────────────────────────────────────────────────────────

    def _build_header(self):
        hdr = ctk.CTkFrame(self, corner_radius=0, fg_color=("gray85", "gray17"))
        hdr.grid(row=0, column=0, sticky="ew")
        hdr.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(hdr, text="🎙  Voice Interpreter",
                     font=ctk.CTkFont(size=22, weight="bold")).grid(row=0, column=0, pady=(14, 2))
        ctk.CTkLabel(hdr,
                     text="Powered by Whisper AI  ·  Bidirectional real-time translation",
                     font=ctk.CTkFont(size=12),
                     text_color=("gray50", "gray60")).grid(row=1, column=0, pady=(0, 12))

    def _build_quick_switch(self):
        """Two large prominent mode buttons for instant switching."""
        qs = ctk.CTkFrame(self, fg_color=("gray88", "gray20"), corner_radius=10)
        qs.grid(row=1, column=0, sticky="ew", padx=20, pady=(14, 0))
        qs.grid_columnconfigure(0, weight=1)
        qs.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(qs, text="Quick Switch",
                     font=ctk.CTkFont(size=11, weight="bold"),
                     text_color=("gray50", "gray55")).grid(
            row=0, column=0, columnspan=2, pady=(8, 4))

        self._mode_btns = []
        configs = [
            ("🎤  My Voice\nEnglish → Russian", 0),
            ("🔊  Friend\nRussian → English", 1),
        ]
        for text, idx in configs:
            btn = ctk.CTkButton(
                qs,
                text=text,
                font=ctk.CTkFont(size=14, weight="bold"),
                height=64,
                corner_radius=8,
                fg_color=COL_INACTIVE,
                hover_color=COL_INACTIVE_HOVER,
                command=lambda i=idx: self._on_mode_btn(i),
            )
            btn.grid(row=1, column=idx, sticky="ew", padx=(12 if idx == 0 else 6, 6 if idx == 0 else 12), pady=(0, 12))
            self._mode_btns.append(btn)

    def _build_controls(self, device_labels):
        outer = ctk.CTkFrame(self, fg_color="transparent")
        outer.grid(row=2, column=0, sticky="ew", padx=20, pady=(12, 0))
        outer.grid_columnconfigure(1, weight=1)

        # Audio source
        ctk.CTkLabel(outer, text="Audio source:", width=130, anchor="w",
                     font=ctk.CTkFont(size=13)).grid(row=0, column=0, sticky="w", pady=3)
        row0 = ctk.CTkFrame(outer, fg_color="transparent")
        row0.grid(row=0, column=1, sticky="w")
        self.device_menu = ctk.CTkOptionMenu(
            row0, variable=self.device_var, values=device_labels, width=340,
            command=self._on_manual_device_change)
        self.device_menu.grid(row=0, column=0)
        ctk.CTkButton(row0, text="⟳", width=34,
                      fg_color=("gray75","gray30"), hover_color=("gray65","gray40"),
                      text_color=("gray10","gray90"),
                      command=self._refresh_devices).grid(row=0, column=1, padx=(8, 0))

        # Translate direction (two dropdowns + arrow)
        ctk.CTkLabel(outer, text="Translate:", width=130, anchor="w",
                     font=ctk.CTkFont(size=13)).grid(row=1, column=0, sticky="w", pady=3)
        row1 = ctk.CTkFrame(outer, fg_color="transparent")
        row1.grid(row=1, column=1, sticky="w")
        lang_names = sorted(LANGUAGES.keys())
        self.src_menu = ctk.CTkOptionMenu(
            row1, variable=self.src_var, values=lang_names, width=160,
            command=self._on_manual_lang_change)
        self.src_menu.grid(row=0, column=0)
        ctk.CTkLabel(row1, text="  →  ",
                     font=ctk.CTkFont(size=16, weight="bold")).grid(row=0, column=1)
        self.tgt_menu = ctk.CTkOptionMenu(
            row1, variable=self.tgt_var, values=lang_names, width=160,
            command=self._on_manual_lang_change)
        self.tgt_menu.grid(row=0, column=2)

        # Model + sensitivity on same row
        ctk.CTkLabel(outer, text="Model / Sensitivity:", width=130, anchor="w",
                     font=ctk.CTkFont(size=13)).grid(row=2, column=0, sticky="w", pady=(6,3))
        row2 = ctk.CTkFrame(outer, fg_color="transparent")
        row2.grid(row=2, column=1, sticky="ew", pady=(6,3))
        row2.grid_columnconfigure(4, weight=1)

        self.model_menu = ctk.CTkOptionMenu(
            row2, variable=self.model_var, values=list(MODELS.keys()), width=230)
        self.model_menu.grid(row=0, column=0, padx=(0, 16))

        self.sens_slider = ctk.CTkSlider(
            row2, from_=0.3, to=2.5, variable=self.sensitivity_var,
            width=160, command=self._on_sensitivity)
        self.sens_slider.grid(row=0, column=1)
        self.sens_label = ctk.CTkLabel(row2, text="1.0×",
                                       font=ctk.CTkFont(size=12), width=38)
        self.sens_label.grid(row=0, column=2, padx=(8, 12))
        ctk.CTkLabel(row2, text="Lower = picks up quieter audio",
                     font=ctk.CTkFont(size=11),
                     text_color=("gray50","gray55")).grid(row=0, column=3)

        # Action buttons
        btns = ctk.CTkFrame(outer, fg_color="transparent")
        btns.grid(row=3, column=0, columnspan=2, sticky="e", pady=(10, 0))
        self.start_btn = ctk.CTkButton(btns, text="▶  Start Listening",
                                       width=160, command=self._toggle_listening)
        self.start_btn.grid(row=0, column=0, padx=(0, 8))
        ctk.CTkButton(btns, text="🔊  Read Aloud", width=130,
                      fg_color=("gray75","gray30"), hover_color=("gray65","gray40"),
                      text_color=("gray10","gray90"),
                      command=self._speak_translation).grid(row=0, column=1, padx=(0,8))
        ctk.CTkButton(btns, text="Clear", width=70,
                      fg_color=("gray75","gray30"), hover_color=("gray65","gray40"),
                      text_color=("gray10","gray90"),
                      command=self._clear).grid(row=0, column=2)

    def _build_text_area(self):
        frame = ctk.CTkFrame(self, fg_color="transparent")
        frame.grid(row=4, column=0, sticky="nsew", padx=20, pady=(12, 0))
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_columnconfigure(1, weight=1)
        frame.grid_rowconfigure(1, weight=1)

        self.heard_label = ctk.CTkLabel(frame, text="Heard (original)",
                                        font=ctk.CTkFont(size=12, weight="bold"))
        self.heard_label.grid(row=0, column=0, sticky="w", padx=4, pady=(0, 4))
        self.translated_label = ctk.CTkLabel(frame, text="Translation",
                                             font=ctk.CTkFont(size=12, weight="bold"))
        self.translated_label.grid(row=0, column=1, sticky="w", padx=(12, 4), pady=(0, 4))

        self.heard_box = ctk.CTkTextbox(frame, wrap="word", font=ctk.CTkFont(size=14))
        self.heard_box.grid(row=1, column=0, sticky="nsew", padx=(0, 6))
        self.translated_box = ctk.CTkTextbox(frame, wrap="word", font=ctk.CTkFont(size=14))
        self.translated_box.grid(row=1, column=1, sticky="nsew", padx=(6, 0))

    def _build_status_bar(self):
        self.status_var = ctk.StringVar(value="Select a mode above, then press Start Listening.")
        ctk.CTkLabel(self, textvariable=self.status_var,
                     font=ctk.CTkFont(size=11),
                     text_color=("gray45","gray55"), anchor="w").grid(
            row=5, column=0, sticky="ew", padx=22, pady=(6, 10))

    # ── Mode switching ────────────────────────────────────────────────────────

    def _on_mode_btn(self, mode_idx: int):
        """User clicked a quick-switch mode button."""
        # Save current manual state back into previous mode
        if self._active_mode is not None:
            self._mode_state[self._active_mode] = [
                self.device_var.get(),
                self.src_var.get(),
                self.tgt_var.get(),
            ]
        self._apply_mode(mode_idx, switch_source=True)

    def _apply_mode(self, mode_idx: int, switch_source: bool = False):
        """Highlight mode button, update dropdowns, optionally restart listening."""
        was_listening = self.is_listening
        if was_listening:
            self._stop_session(keep_mode=True)

        self._active_mode = mode_idx
        device_lbl, src_lang, tgt_lang = self._mode_state[mode_idx]

        if switch_source and device_lbl:
            self.device_var.set(device_lbl)
        self.src_var.set(src_lang)
        self.tgt_var.set(tgt_lang)

        # Update column headers
        self.heard_label.configure(text=f"Heard in {src_lang}")
        self.translated_label.configure(text=f"Translation → {tgt_lang}")

        # Update button colours
        colours = [COL_MY_VOICE_ACTIVE, COL_FRIEND_ACTIVE]
        hovers  = [COL_MY_VOICE_HOVER,  COL_FRIEND_HOVER]
        for i, btn in enumerate(self._mode_btns):
            if i == mode_idx:
                btn.configure(fg_color=colours[i], hover_color=hovers[i])
            else:
                btn.configure(fg_color=COL_INACTIVE, hover_color=COL_INACTIVE_HOVER)

        if was_listening:
            self._start_session()
        else:
            label, _, keywords = (
                ("My Voice (EN→RU)", "🎤", NVIDIA_KEYWORDS),
                ("Friend (RU→EN)",   "🔊", VB_KEYWORDS),
            )[mode_idx]
            self.status_var.set(f"Mode: {label}  —  press Start Listening.")

    def _on_manual_device_change(self, _=None):
        """User manually changed device — deactivate quick-mode highlighting."""
        if self.is_listening:
            self._stop_session()
            self.status_var.set("Device changed — press Start Listening again.")

    def _on_manual_lang_change(self, _=None):
        src = self.src_var.get()
        tgt = self.tgt_var.get()
        self.heard_label.configure(text=f"Heard in {src}")
        self.translated_label.configure(text=f"Translation → {tgt}")
        if self.is_listening:
            self._stop_session()
            self.status_var.set("Language changed — press Start Listening again.")

    def _refresh_devices(self):
        was = self.is_listening
        if was: self._stop_session()
        self.audio_devices = get_audio_input_devices()
        self._device_map   = {lbl: idx for idx, lbl in self.audio_devices}
        labels = [lbl for _, lbl in self.audio_devices]
        self.device_menu.configure(values=labels)
        if self.device_var.get() not in labels:
            self.device_var.set(labels[0] if labels else "")
        # Re-detect special devices and update mode defaults
        nvidia_lbl = find_device_by_keywords(self.audio_devices, NVIDIA_KEYWORDS)
        vb_lbl     = find_device_by_keywords(self.audio_devices, VB_KEYWORDS)
        if nvidia_lbl: self._mode_state[0][0] = nvidia_lbl
        if vb_lbl:     self._mode_state[1][0] = vb_lbl
        self.status_var.set(f"Refreshed — {len(labels)} input device(s) found.")

    # ── Session start / stop ────────────────────────────────────────────────

    def _toggle_listening(self):
        if self.is_listening:
            self._stop_session()
        else:
            self._start_session()

    def _start_session(self):
        self.is_listening = True
        self.start_btn.configure(text="⏹  Stop Listening",
                                 fg_color=COL_STOP, hover_color=COL_STOP_HOVER)
        self._set_controls_state("disabled")

        dev_idx = self._device_map.get(self.device_var.get(), -1)
        if dev_idx == -1: dev_idx = None

        src_key     = self.src_var.get()
        tgt_key     = self.tgt_var.get()
        src_whisper, _ = LANGUAGES.get(src_key, ("en", "en"))
        model_size  = MODELS[self.model_var.get()]

        self.phrase_queue = queue.Queue()

        self._capture_thr = AudioCaptureThread(
            device_index=dev_idx,
            phrase_queue=self.phrase_queue,
            status_cb=lambda m: self.result_queue.put(("status", m)),
        )
        self._capture_thr.set_sensitivity(round(self.sensitivity_var.get(), 1))
        self._capture_thr.start()

        self._transcribe_thr = TranscriptionThread(
            model_size=model_size,
            src_whisper=src_whisper,
            src_lang_key=src_key,
            tgt_lang_key=tgt_key,
            phrase_queue=self.phrase_queue,
            result_queue=self.result_queue,
            status_cb=lambda m: self.result_queue.put(("status", m)),
        )
        self._transcribe_thr.start()

    def _stop_session(self, keep_mode=False):
        self.is_listening = False
        if self._capture_thr:
            self._capture_thr.stop(); self._capture_thr = None
        if self._transcribe_thr:
            self._transcribe_thr.stop(); self._transcribe_thr = None
        self.start_btn.configure(text="▶  Start Listening",
                                 fg_color=["#3B8ED0","#1F6AA5"],
                                 hover_color=["#3281BC","#1A5C8F"])
        self._set_controls_state("normal")
        if not keep_mode:
            self.status_var.set('Stopped. Press "Start Listening" to resume.')

    def _set_controls_state(self, state):
        for w in (self.device_menu, self.src_menu, self.tgt_menu,
                  self.model_menu, self.sens_slider):
            w.configure(state=state)

    # ── TTS / Clear ────────────────────────────────────────────────────────

    def _speak_translation(self):
        if not self.tts:
            self.status_var.set("Text-to-speech not available."); return
        text = self.translated_box.get("1.0","end-1c").strip()
        if not text:
            self.status_var.set("Nothing to read."); return
        def _run():
            try: self.tts.say(text); self.tts.runAndWait()
            except Exception: pass
        threading.Thread(target=_run, daemon=True).start()

    def _clear(self):
        if self.is_listening: self._stop_session()
        self.heard_box.delete("1.0","end")
        self.translated_box.delete("1.0","end")
        self.status_var.set('Cleared. Press "Start Listening" to begin.')

    # ── Queue poll ──────────────────────────────────────────────────────────

    def _on_sensitivity(self, val):
        v = round(float(val), 1)
        self.sens_label.configure(text=f"{v}×")
        if self._capture_thr:
            self._capture_thr.set_sensitivity(v)

    def _poll_queue(self):
        try:
            while True:
                kind, data = self.result_queue.get_nowait()
                if kind == "heard":
                    self._append(self.heard_box, data)
                    self.status_var.set("Transcribed — translating…")
                elif kind == "translate":
                    text, src_k, tgt_k = data
                    threading.Thread(
                        target=translate_worker,
                        args=(text, src_k, tgt_k, self.result_queue),
                        daemon=True).start()
                elif kind == "translated":
                    self._append(self.translated_box, data)
                    self.status_var.set(
                        "Translated. Listening…" if self.is_listening else "Done.")
                elif kind == "status":
                    self.status_var.set(data)
        except queue.Empty:
            pass
        self.after(80, self._poll_queue)

    @staticmethod
    def _append(box, text):
        cur = box.get("1.0","end-1c")
        box.insert("end", ("\n" if cur else "") + text)
        box.see("end")


if __name__ == "__main__":
    app = InterpreterApp()
    app.mainloop()
