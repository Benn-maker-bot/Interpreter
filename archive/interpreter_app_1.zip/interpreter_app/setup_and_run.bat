@echo off
title Voice Interpreter - Setup
color 0A
echo.
echo  ============================================
echo   Voice Interpreter - First-time Setup
echo  ============================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found.
    echo  Install Python 3.9+ from https://python.org
    echo  Tick "Add Python to PATH" during install.
    pause & exit /b 1
)
echo  [OK] Python found.
echo.
echo  Installing packages (this may take a few minutes)...
echo.

pip install customtkinter deep-translator pyttsx3 pyaudio numpy --quiet
if errorlevel 1 (
    echo  PyAudio install failed, trying fallback...
    pip install pipwin --quiet
    pipwin install pyaudio --quiet
)

echo.
echo  Installing faster-whisper (AI speech engine)...
pip install faster-whisper --quiet
echo.
echo  [OK] All packages installed.
echo.
echo  NOTE: The first time you press "Start Listening", the Whisper
echo  model will be downloaded (~450 MB for Small). This only happens
echo  once and is cached for all future sessions.
echo.
echo  Starting Voice Interpreter...
echo.
python interpreter.py
pause
